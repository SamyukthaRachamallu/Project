//
//  HospitalTableViewCell.swift
//  Petcare
//
//  Created by Charan on 18/12/23.
//

import UIKit

class HospitalTableViewCell: UITableViewCell {
    
    @IBOutlet weak var HospitalName : UILabel!
    @IBOutlet weak var Delete: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
