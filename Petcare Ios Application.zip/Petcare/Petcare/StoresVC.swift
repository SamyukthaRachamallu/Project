//
//  StoresVC.swift
//  Petcare
//
//  Created by SAIL on 16/10/23.
//

import UIKit

class StoresVC: UIViewController {
    
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var storeNameLabel: UILabel!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var banner: UIImageView!
    
    var pass: Servicetype!
    
    var sender: [String:Any] = [String:Any]()
    
    @IBOutlet weak var storesCollectionView: UICollectionView! {
        
        didSet {
            storesCollectionView.delegate = self
            storesCollectionView.dataSource = self
       //     storesCollectionView.collectionViewLayout = self
//            self.storesCollectionView.reloadData()
//            ServiceAPI()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        UserDefaultsManager.shared.savePetType("dog")
        
        if UserDefaultsManager.shared.getType() == "Veterinary" {
            self.storeNameLabel.text = "Veterinary Store"
        } else if UserDefaultsManager.shared.getType() == "Training" {
            self.storeNameLabel.text = "Training Store"
        } else if UserDefaultsManager.shared.getType() == "Grooming" {
            self.storeNameLabel.text = "Grooming Store"
        } else if UserDefaultsManager.shared.getType() == "Walking" {
            self.storeNameLabel.text = "Walking Store"
        }
        
        self.banner.image = UIImage(named: "1")
        
        ServiceAPI()
//        self.storesCollectionView.reloadData()
        
        let numbersOfColumns: CGFloat = 2
        let columnSpacing: CGFloat = (numbersOfColumns - 1) * 10
        let width = (self.view.frame.size.width - columnSpacing) / numbersOfColumns
        let layout = storesCollectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: width, height: width)

        let direction = UICollectionViewFlowLayout()
        direction.scrollDirection = .vertical
        direction.itemSize = CGSize(width: self.storesCollectionView.frame.size.width / 1.7, height: 250.0)
        self.storesCollectionView.collectionViewLayout = direction
    }
    override func viewWillAppear(_ animated: Bool) {
        UserDefaultsManager.shared.savePetType("Dog")
        ServiceAPI()
//        self.storesCollectionView.reloadData()
    }
    
    func ServiceAPI() {
            APIHandler.shared.getAPIValues(type: Servicetype.self, apiUrl: Constants.serviceType.ServiceAPI ,method:"GET") { result in
                switch result {
                case .success(let data):
                    print(data)
                    self.pass = data
                    print(self.pass.data ?? "")
                    print(self.pass.data?.first?.image ?? "")
                    DispatchQueue.main.async {
                        self.storesCollectionView.reloadData()
                        self.countLabel.text = "\(self.pass.data?.count ?? 0) Items"
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async {
                        // Handle error if needed
                    }
                }
            }
        }
    
    @IBAction func segmentControllAction(_ sender: Any) {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            print("Dog")
            UserDefaultsManager.shared.savePetType("Dog")
            self.banner.image = UIImage(named: "1")
            ServiceAPI()
            self.storesCollectionView.reloadData()
        case 1:
            print("Cat")
            UserDefaultsManager.shared.savePetType("Cat")
            self.banner.image = UIImage(named: "2")
            ServiceAPI()
            self.storesCollectionView.reloadData()
        default:
            break
        }
    }
    
    
    // Do any additional setup after loading the view
    
    
    @IBAction func backAction(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        dismiss(animated: true)
    }
    
}


extension StoresVC: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.pass?.data?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "StoresCollectionViewCell", for: indexPath) as! StoresCollectionViewCell
        
            guard let detail = self.pass?.data?[indexPath.row] else {
                cell.titleLabel.text = ""
                cell.nameLabel.text = ""
                cell.costLabel.text = ""
                return cell
            }

            configureCell(cell, detail: detail)
            return cell
        }

        func configureCell(_ cell: StoresCollectionViewCell, detail: type) {
            cell.titleLabel.text = " \(detail.type ?? "")"
            cell.nameLabel.text = " \(detail.type ?? "")"
            cell.costLabel.text = " ₹ \(detail.amount  ?? 0)"

            if let imageURLString = detail.image,
               let imgURL = URL(string: imageURLString),
               let data = try? Data(contentsOf: imgURL) {
                cell.image.image = UIImage(data: data)
            } else {
                cell.image.image = nil
            }
        }

    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        let padding: CGFloat =  25
//            let collectionViewSize = storesCollectionView.frame.size.width - padding
//        return CGSize(width: collectionViewSize/2.2, height: 115)
//    }
//
//        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
//            return UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
//        }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let detail = self.pass?.data?[indexPath.row] {
            let title = detail.type ?? ""
            UserDefaultsManager.shared.savetype(title)
            
            //        let vc = storyboard?.instantiateViewController(withIdentifier: "DogvaccinationVC") as! DogvaccinationVC
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyboard.instantiateViewController(withIdentifier: "DogvaccinationVC") as! DogvaccinationVC
            viewController.providesPresentationContextTransitionStyle = true
            viewController.definesPresentationContext = true
            viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
            
            if let imageFileName = detail.image, !imageFileName.isEmpty {
                self.sender = ["Title": title, "Name": title, "Cost": detail.amount ?? "", "Image": imageFileName]
            } else {
                self.sender = ["Title": title, "Name": title, "Cost": detail.amount ?? ""]
            }
            
            viewController.receiver = self.sender
            self.present(viewController, animated: true)
        }
    }
    
//    
//        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
//            return 5
//        }
    
}

