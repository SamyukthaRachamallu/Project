//
//  ScheduleVC.swift
//  Petcare
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class ScheduleVC: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var hospitalTF: UITextField!
    
    var userId = UserDefaultsManager.shared.getID()
    var hospital : MyHospital!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        hospitalTF.delegate = self
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: datePicker.date) // Formatted date string

        dateFormatter.dateFormat = "ha"
        let startTime = dateFormatter.string(from: datePicker.date) // Formatted start time string

        // Assuming you want to set the end time to 4 hours later
        datePicker.date = datePicker.date.addingTimeInterval(4 * 3600) // Add 4 hours (4 * 3600 seconds) to get the end time
        let endTime = dateFormatter.string(from: datePicker.date) // Formatted end time string

        let timeString = "\(startTime)-\(endTime)" // Combine start and end times
        
        UserDefaultsManager.shared.saveDate(dateString)
        UserDefaultsManager.shared.saveTime(timeString)
        
        UserDefaultsManagers.shared.setValue(dateString, forKey: "Date")
        UserDefaultsManagers.shared.setValue(timeString, forKey: "Time")
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        let alert = UIAlertController(title: "Select Hospital", message: "", preferredStyle: .actionSheet)
        for type in hospital.data ?? [] {
            alert.addAction(UIAlertAction(title: type.title, style: .default, handler: { action in
                self.hospitalTF.text = "\(type)"
            }))
        }
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        self.present(alert, animated: true)
    }
    
    @IBAction func closeAction(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func confirmSlotsAction(_ sender: Any) {
//        DateAPI()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "SelectpetVC") as! SelectpetVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
        viewController.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
    }
    override func viewWillAppear(_ animated: Bool) {
        MyHospitalAPI()
    }
    
    func MyHospitalAPI() {
        APIHandler().getAPIValues(type: MyHospital.self, apiUrl: Constants.serviceType.HospitalAPI.rawValue, method: "GET") { result in
            switch result {
            case .success(let data):
                self.hospital = data
                print(self.hospital.data ?? "")
                
                DispatchQueue.main.async {
                    self.hospitalTF.text = self.hospital?.data?.first?.title
//                    self.amount.text = self.pass.data?.first?.amount
//                    self.type.text = self.pass.data?.first?.type
//                    self.titletype.text = self.pass.data?.first?.type
//                    self.labeltype.text = self.pass.data?.first?.type
                    
                    
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            }
        }
    }
    
    func DateAPI() {
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateStyle = .medium
//        dateFormatter.timeStyle = .none
//
//        let date = dateFormatter.string(from: datePicker.date)
//        dateFormatter.dateStyle = .none
//        dateFormatter.timeStyle = .medium
//        let time =  dateFormatter.string(from: datePicker.date)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: datePicker.date) // Formatted date string

        dateFormatter.dateFormat = "ha"
        let startTime = dateFormatter.string(from: datePicker.date) // Formatted start time string

        // Assuming you want to set the end time to 4 hours later
        datePicker.date = datePicker.date.addingTimeInterval(4 * 3600) // Add 4 hours (4 * 3600 seconds) to get the end time
        let endTime = dateFormatter.string(from: datePicker.date) // Formatted end time string

        let timeString = "\(startTime)-\(endTime)" // Combine start and end times

        let formData: [String: String] = [
            "AppointmentDate": dateString,
            "AppointmentTime": timeString,
            "UserID": self.userId 
        ]
        APIHandler().postAPIValues(type: DateJson.self, apiUrl: Constants.serviceType.DateAPI.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    print(formData)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
    
}
