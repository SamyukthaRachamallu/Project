//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit

public class Constants {
    
    var petType : String? {
            return UserDefaultsManager.shared.getPetType()
        }
    
    var service : String? {
            return UserDefaultsManager.shared.getType()
        }
    
    var userId : String? {
            return UserDefaultsManager.shared.getUserId()
        }
    var Id : String? {
            return UserDefaultsManager.shared.getID()
        }
    var type : String? {
            return UserDefaultsManager.shared.gettype()
        }
  
    // 192.168.11.170
    enum serviceType: String {
        case Signupurl = "http://172.17.51.42/petios/signup.php?"
        case AdminAPI = "http://172.17.51.42/petios/page.php?"
        case TrainingAPI = "http://172.17.51.42/petios/training.php?"
        case GrommingAPI = "http://172.17.51.42/petios/gromming.php?"
        case WalkingAPI = "http://172.17.51.42/petios/Walking.php?"
        case AddserviceAPI = "http://172.17.51.42/petios/service1.php?"
        case ConfrimAPI = "http://172.17.51.42/petios/confrim.php?"
        case CancelAPI = "http://172.17.51.42/petios/cancel.php?"
        case DeleteAPI = "http://172.17.51.42/petios/deleteService.php?"
        case DateAPI = "http://172.17.51.42/petios/dateandtime.php?"
        case selectingpetAPI = "http://172.17.51.42/petios/selectingpet.php?"
        case AddingpetAPI = "http://172.17.51.42/petios/addingpet.php?"
        case ProfileUpdateAPI = "http://172.17.51.42/petios/profileupdate.php?"
        case AddAddressAPI = "http://172.17.51.42/petios/AddAddress.php?"
        case BookingAPI = "http://172.17.51.42/petios/booking.php?"
        case ConfirmedCount = "http://172.17.51.42/petios/confirmed.php"
        case CancelledCount = "http://172.17.51.42/petios/cancelled.php"
        case AddHospitalAPI = "http://172.17.51.42/petios/addhospital.php?"
        case HospitalAPI = "http://172.17.51.42/petios/designation.php"
        static var AccountAPI : String {
                    if let userID = Constants().userId {
                        return "http://172.17.51.42/petios/profile.php?UserID=\(userID)"
                    } else {
                        return ""
                    }
                }
        static var PetAPI : String {
                    if let ID = Constants().Id {
                        return "http://172.17.51.42/petios/mypet.php?UserID=\(ID)"
                    } else {
                        return ""
                    }
                }
        static var RequestAPI : String {
                    if let ID = Constants().Id {
                        return "http://172.17.51.42/petios/specificbookings.php?UserID=\(ID)"
                    } else {
                        return ""
                    }
                }
        static var HomeAPI : String {
                    if let userID = Constants().userId {
                        return "http://172.17.51.42/petios/home.php?UserID=\(userID)"
                    } else {
                        return ""
                    }
                }
        static var ServiceAPI : String {
            
            if let petType = Constants().petType, let service = Constants().service  {
                        return "http://172.17.51.42/petios/servicetype.php?petType=\(petType)&service=\(service)"
                    } else {
                        return ""
                    }
                }
        static var SelectPetAPI : String {
                    if let ID = Constants().Id  {
                        return "http://172.17.51.42/petios/selectingpet.php?UserID=\(ID)"
                    } else {
                        return ""
                    }
                }
        static var InfoAPI : String {
            if let type = Constants().type {
                        return "http://172.17.51.42/petios/informationpage.php?type=\(type)"
                    } else {
                        return ""
                    }
                }
        static var CartAPI : String {
            if let type = Constants().type, let service = Constants().service  {
                        return "http://172.17.51.42/petios/servicetype.php?type=\(type)&service=\(service)"
                    } else {
                        return ""
                    }
                }
        static var AddressAPI : String {
                    if let ID = Constants().Id {
                        return "http://172.17.51.42/petios/Address.php?user_id=\(ID)"
                    } else {
                        return ""
                    }
                }
        static var BookingsAPI : String {
                    if let ID = Constants().Id {
                        return "http://172.17.51.42/petios/mybookings.php?UserID=\(ID)"
                    } else {
                        return ""
                    }
                }
    }
   
    
    static let Signupurl: serviceType = .Signupurl
    static let Adminurl: serviceType = .AdminAPI
}

