//
//  addhospitalModel.swift
//  Petcare
//
//  Created by Charan on 18/12/23.
//

import Foundation
struct AddHospitalJson: Codable {
    var status, message: String?
}
