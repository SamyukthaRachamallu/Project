//
//  DoctorVC.swift
//  Petcare
//
//  Created by Charan on 18/12/23.
//

import UIKit

// ... (Your imports and other parts of the code)

class DoctorVC: UIViewController {

    @IBOutlet weak var addhospitalButton: UIButton!
    @IBOutlet weak var HospitalTV: UITableView!
    var pass: Hospital!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.HospitalTV.delegate = self
        self.HospitalTV.dataSource = self
    }

    override func viewWillAppear(_ animated: Bool) {
        HospitalAPI()
    }

    @IBAction func BackButtonAction(_ sender: Any) {
        dismiss(animated: true)
        
    }
    @IBAction func addHospitalButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "AddHospitalVC") as! AddHospitalVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    func HospitalAPI() {
        APIHandler.shared.getAPIValues(type: Hospital.self, apiUrl: Constants.serviceType.HospitalAPI.rawValue, method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data)
                print(self.pass.data?.count)
                DispatchQueue.main.async {
                    self.HospitalTV.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    // Handle failure
                }
            }
        }
    }
}

extension DoctorVC: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.pass?.data?.count ?? 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HospitalTableViewCell", for: indexPath) as! HospitalTableViewCell

        if let detail = self.pass?.data?[indexPath.row] {
            if let title = detail.title, !title.isEmpty {
                cell.HospitalName.text = "  \(title)"
            } else {
                cell.HospitalName.text = "Nil"
            }
        }
        return cell
    }


    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}



