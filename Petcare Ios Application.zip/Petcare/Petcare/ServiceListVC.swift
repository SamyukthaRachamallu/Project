//
//  ServiceListVC.swift
//  Petcare
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class ServiceListVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func backAction(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        dismiss(animated: true)
    }
    
    @IBAction func veterinaryAction(_ sender: Any) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "VeterinaryVC") as! VeterinaryVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "VeterinaryVC") as! VeterinaryVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
    @IBAction func trainingAction(_ sender: Any) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "TrainingVC") as! TrainingVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "TrainingVC") as! TrainingVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
    @IBAction func groomingAction(_ sender: Any) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "GroomingVC") as! GroomingVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "GroomingVC") as! GroomingVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
    @IBAction func walkingAction(_ sender: Any) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "WalkingVC") as! WalkingVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "WalkingVC") as! WalkingVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
}
