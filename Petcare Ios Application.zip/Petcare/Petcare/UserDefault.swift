//
//  UserDefault.swift
//  building management
//
//  Created by SAIL on 09/10/23.
//

import Foundation

class UserDefaultsManager {
    static let shared = UserDefaultsManager()

    private let userDefaults = UserDefaults.standard

    private init() {}

    // MARK: - Define Keys for Your Data
    private let userIdKey = "UserId"
    private let userProfileKay = "UserProfile"
    private let IDKey = "UserAge"
    private let TypeKey = "ProductType"
    private let petTypeKey = "PetType"
    private let typeKey = "type"
    private let gender = "type"
    private let dateKey = "Date"
    private let timeKey = "Time"
    private let amountKey = "Amount"
    private let addressKey = "Address"

    // MARK: - Save Data
    func saveUserId(_ name: String) {
        userDefaults.set(name, forKey: userIdKey)
    }
    
    func saveUserProfile(_ name: String) {
        userDefaults.set(name, forKey: userProfileKay)
    }

    func saveID(_ age: String) {
        userDefaults.set(age, forKey: IDKey)
    }
    
    func saveType(_ name: String) {
        userDefaults.set(name, forKey: TypeKey)
    }
    
    func savePetType(_ name: String) {
        userDefaults.set(name, forKey: petTypeKey)
    }
    
    func savegender(_ name: String) {
        userDefaults.set(name, forKey: gender)
    }
    
    func saveDate(_ name: String) {
        userDefaults.set(name, forKey: dateKey)
    }
    
    func saveTime(_ name: String) {
        userDefaults.set(name, forKey: timeKey)
    }
    
    func saveAmount(_ name: String) {
        userDefaults.set(name, forKey: amountKey)
    }
    
    func saveAddress(_ name: String) {
        userDefaults.set(name, forKey: addressKey)
    }

    // MARK: - Retrieve Data
    func getUserId() -> String? {
        return userDefaults.string(forKey: userIdKey)
    }
    
    func getUserProfile() -> String? {
        return userDefaults.string(forKey: userProfileKay)
    }

    func getID() -> String {
        return userDefaults.string(forKey: IDKey) ?? ""
    }
    
    func getType() -> String? {
        return userDefaults.string(forKey: TypeKey)
    }
    
    func getPetType() -> String? {
        return userDefaults.string(forKey: petTypeKey)
    }
    
    func getgender() -> String? {
        return userDefaults.string(forKey: gender)
    }
    
    func getDate() -> String? {
        return userDefaults.string(forKey: dateKey)
    }
    
    func getTime() -> String? {
        return userDefaults.string(forKey: timeKey)
    }
    
    func getAmount() -> String? {
        return userDefaults.string(forKey: amountKey)
    }
    
    func getAddress() -> String? {
        return userDefaults.string(forKey: addressKey)
    }

    // MARK: - Remove Data (if needed)
    func removeUserData() {
        userDefaults.removeObject(forKey: userIdKey)
        userDefaults.removeObject(forKey: IDKey)
    }
    func gettype() -> String? {
        return userDefaults.string(forKey: typeKey)
    }
    func savetype(_ name: String) {
        userDefaults.set(name, forKey: typeKey)
    }
}

