//
//  LoginVC.swift
//  Petcare
//
//  Created by SAIL L1 on 27/09/23.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var usenameTF: UITextField!
    @IBOutlet weak var PasswordTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        PasswordTF.isSecureTextEntry = true
    }
    let apiHandler : APIHandler = APIHandler()
    var apiData : LoginJSON!
    var apiUrl = String()


  /*  @IBAction func loginAc(_ sender: Any) {
        let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "InitialTabBar") as! InitialTabBar
        self.navigationController?.pushViewController(nextVc, animated: true)
    } */
    
    @IBAction func backAction(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        dismiss(animated: true)
    }
    
    func isValidEmailAddress(emailAddressString: String) -> Bool {
            
            var returnValue = true
            let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
            
            do {
                let regex = try NSRegularExpression(pattern: emailRegEx)
                let nsString = emailAddressString as NSString
                let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
                
                if results.count == 0
                {
                    returnValue = false
                }
                
            } catch let error as NSError {
                print("invalid regex: \(error.localizedDescription)")
                returnValue = false
            }
            
            return  returnValue
        }
    
    @IBAction func loginAc(_ sender: Any) {
            apiUrl = "http://172.17.51.42/petios/login.php?email=\(usenameTF.text ?? "")&pass=\(PasswordTF.text ?? "")"
        if usenameTF.text == "" && PasswordTF.text == "" {
                   let alert = UIAlertController(title: "Field is empty", message: "Please enter Email / Password", preferredStyle: UIAlertController.Style.alert)
                   alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                   present(alert, animated: true)
        } else if isValidEmailAddress(emailAddressString: usenameTF.text ?? "") != true{
            AlertManager.showAlert(title: "Error", message: "Invalid email", viewController: self)
        } else {
            GetAPI()
        }
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "InitialTabBar") as! InitialTabBar
//    self.navigationController?.pushViewController(vc, animated: true)

        }
    
    func GetAPI() {
           APIHandler.shared.getAPIValues(type: LoginJSON.self, apiUrl: apiUrl, method: "GET") { result in
               switch result {
               case .success(let data):
                   print(data)
                   self.apiData = data
                   DispatchQueue.main.async {
                       if self.usenameTF.text != self.apiData.data?.first?.email {
                           let alert = UIAlertController(title: "Alert", message: "Incorrect UserID or Password", preferredStyle: UIAlertController.Style.alert)
                           alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                           self.present(alert, animated: true)
                       } else {
                           if self.apiData.data?.first?.isAdmin == "1" {
                               UserDefaultsManager.shared.saveUserProfile("1")  
                               UserDefaultsManager.shared.saveUserId(self.usenameTF.text ?? "")
                               UserDefaultsManager.shared.saveID(self.apiData.data?.first?.userID ?? "")
                               let storyboard = UIStoryboard(name: "Main", bundle: nil)
                               let viewController = storyboard.instantiateViewController(withIdentifier: "AdminViewController") as! AdminViewController
                               viewController.providesPresentationContextTransitionStyle = true
                               viewController.definesPresentationContext = true
                               viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
                               self.present(viewController, animated: true)
                           } else if self.apiData.data?.first?.designation == "0" {
                               UserDefaultsManager.shared.saveUserProfile("0")
                               UserDefaultsManager.shared.saveUserId(self.usenameTF.text ?? "")
                               UserDefaultsManager.shared.saveID(self.apiData.data?.first?.userID ?? "")
                               let storyboard = UIStoryboard(name: "Main", bundle: nil)
                               let viewController = storyboard.instantiateViewController(withIdentifier: "InitialTabBar") as! InitialTabBar
                               viewController.providesPresentationContextTransitionStyle = true
                               viewController.definesPresentationContext = true
                               viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
                               self.present(viewController, animated: true)
                           } else if self.apiData.data?.first?.designation != "0" {
                               UserDefaultsManager.shared.saveUserProfile("2")
                               UserDefaultsManager.shared.saveUserId(self.usenameTF.text ?? "")
                               UserDefaultsManager.shared.saveID(self.apiData.data?.first?.userID ?? "")
                               let storyboard = UIStoryboard(name: "Main", bundle: nil)
                               let viewController = storyboard.instantiateViewController(withIdentifier: "DashboardVC") as! DashboardVC
                               viewController.providesPresentationContextTransitionStyle = true
                               viewController.definesPresentationContext = true
                               viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
                               self.present(viewController, animated: true)
                           }
                       }
                   }
               case .failure(let error):
                   print(error)
               }
           }
       }

}

