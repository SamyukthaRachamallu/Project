//
//  InitialCollectionViewCell.swift
//  Petcare
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class InitialCollectionViewCell: UICollectionViewCell {
    
}
