//
//  addressTableViewCell.swift
//  Petcare
//
//  Created by SAIL on 30/10/23.
//

import UIKit

class addressTableViewCell: UITableViewCell {
    
    @IBOutlet weak var UserName: UILabel!
    @IBOutlet weak var Address: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
