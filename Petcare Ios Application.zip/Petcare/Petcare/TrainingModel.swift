//
//  TrainingModel.swift
//  Petcare
//
//  Created by SAIL on 19/10/23.
//
import Foundation

// MARK: - Welcome
struct Training: Codable {
    var data: [sem]?
}

// MARK: - Datum
struct sem: Codable {
    var service, type, petType, amount: String?
     var serviceID: String?

     enum CodingKeys: String, CodingKey {
         case service = "Service"
         case type = "Type"
         case petType = "PetType"
         case amount = "Amount"
         case serviceID = "ServiceID"
     }
 }

enum PetType: String, Codable {
    case cat = "Cat"
    case dog = "Dog"
}

enum Service: String, Codable {
    case training = "Training"
}

