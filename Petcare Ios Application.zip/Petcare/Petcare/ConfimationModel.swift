//
//  ConfimationModel.swift
//  Petcare
//
//  Created by Haris Madhavan on 18/11/23.
//

import Foundation

// MARK: - ConfirmationModel
struct ConfirmationModel: Codable {
    var data: [Confirm]?
}

// MARK: - Datum
struct Confirm: Codable {
    var confirmedBookingsCount: String?

    enum CodingKeys: String, CodingKey {
        case confirmedBookingsCount = "confirmed_bookings_count"
    }
}
