//
//  AccountModel.swift
//  Petcare
//
//  Created by SAIL on 17/10/23.
//
import Foundation

// MARK: - Welcome
struct Account: Codable {
    var status: Bool?
    var message: String?
    var data: [acc]?
}

// MARK: - Datum
struct acc: Codable {
    var name, email, phoneNumber: String?

    enum CodingKeys: String, CodingKey {
        case name = "Name"
        case email = "Email"
        case phoneNumber = "PhoneNumber"
    }
}
