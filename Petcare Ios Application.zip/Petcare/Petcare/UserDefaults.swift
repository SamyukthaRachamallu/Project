//
//  UserDefaults.swift
//  Petcare
//
//  Created by SAIL on 01/11/23.
//

import Foundation


class UserDefaultsManagers {
    static let shared = UserDefaultsManagers()

    private let userDefaults = UserDefaults.standard

    private init() {}

    // MARK: - Save Data
    func setValue<T>(_ value: T, forKey key: String) {
        userDefaults.set(value, forKey: key)
    }

    // MARK: - Retrieve Data
    func getValue<T>(forKey key: String) -> T? {
        return userDefaults.value(forKey: key) as? T
    }

    // MARK: - Remove Data (if needed)
    func removeValue(forKey key: String) {
        userDefaults.removeObject(forKey: key)
    }
}
