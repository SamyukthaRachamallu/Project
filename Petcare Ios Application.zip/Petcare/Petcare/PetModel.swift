//
//  PetModel.swift
//  Petcare
//
import Foundation

// MARK: - Welcome
struct Pet: Codable {
    var data: [mypet]?
}

// MARK: - Datum
struct mypet: Codable {
    var petName, breed, petGender, birthDay: String?
    var petType: String?

    enum CodingKeys: String, CodingKey {
        case petName = "PetName"
        case breed = "Breed"
        case petGender = "PetGender"
        case birthDay = "BirthDay"
        case petType = "PetType"
    }
}

