//
//  RequestModel.swift
//  Petcare
//
//  Created by SAIL on 25/10/23.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)


import Foundation

// MARK: - Request
struct Request: Codable {
    var status: Bool
    var message: String
    var data: [Model]?
}

// MARK: - Datum
struct Model: Codable {
    var userID, bookingID, service, pickupAddress, appointmentDate: String?
    var confirmed: String?

    enum CodingKeys: String, CodingKey {
        case userID = "UserID"
        case bookingID = "BookingID"
        case service = "Service"
        case pickupAddress = "PickupAddress"
        case appointmentDate = "AppointmentDate"
        case confirmed
    }
}

