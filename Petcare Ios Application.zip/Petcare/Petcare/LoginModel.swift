//
//  LoginModel.swift
//  Petcare
//
//  Created by SAIL on 14/10/23.
//

import Foundation
struct LoginJSON: Codable {
    var status: Bool?
    var message: String?
    var data: [login]?
}

// MARK: - Datum
struct login: Codable {
    var userID, name, email, phoneNumber: String?
    var password, isAdmin, designation: String?

    enum CodingKeys: String, CodingKey {
        case userID = "UserID"
        case name = "Name"
        case email = "Email"
        case phoneNumber = "PhoneNumber"
        case password = "Password"
        case isAdmin
        case designation
    }
}

