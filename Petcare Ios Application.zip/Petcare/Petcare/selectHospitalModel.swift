//
//  selectHospitalModel.swift
//  Petcare
//
//  Created by Charan on 20/12/23.
//

import Foundation

// MARK: - Hospital
struct MyHospital: Codable {
    var data: [myhospital]?
}

// MARK: - Datum
struct myhospital: Codable {
    var designationID, title: String?

    enum CodingKeys: String, CodingKey {
        case designationID = "DesignationID"
        case title = "Title"
    }
}
