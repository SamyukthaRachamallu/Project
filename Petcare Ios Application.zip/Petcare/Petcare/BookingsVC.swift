//
//  BookingsVC.swift
//  Petcare
//
//  Created by SAIL on 01/11/23.
//

import UIKit

class BookingsVC: UIViewController {
    var pass: Bookings!
    
    @IBOutlet weak var notificationTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.notificationTableView.delegate = self
        self.notificationTableView.dataSource = self
        //        self.notificationTableView.register(UINib(nibName: "NotificationTableViewCell", bundle: nil), forCellReuseIdentifier: "NotificationTableViewCell")
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func backAction(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        dismiss(animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        BookingsAPI()
    }
    
    func BookingsAPI() {
        APIHandler.shared.getAPIValues(type: Bookings.self, apiUrl: Constants.serviceType.BookingsAPI, method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.pass = data
                print(self.pass.data ?? "")
                DispatchQueue.main.async {
                    self.notificationTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}

extension BookingsVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pass?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BookingTableViewCell", for: indexPath) as! BookingTableViewCell
        
        if let data = self.pass?.data, indexPath.row < data.count {
            let detail = data[indexPath.row]
            
            cell.BookingID.text = "BookingID: \(detail.bookingID ?? "")"
            cell.Service.text = "Service: \(detail.service ?? "")"
            cell.Address.text = "PickupAddress: \(detail.pickupAddress ?? "")"
            cell.AppoinmentDate.text = "AppointmentDate: \(detail.appointmentDate  ?? "")"
        } else {
            cell.BookingID.text = "No Data"
            cell.Service.text = ""
            cell.Address.text = ""
            cell.AppoinmentDate.text = ""
        }
        
        let booking = self.pass?.data?[indexPath.row]
        
        switch booking?.confirmed {
        case "1":
            cell.AcceptButton.setTitle("Accepted", for: .normal)
        case "0":
            cell.AcceptButton.setTitle("Cancelled", for: .normal)
        default:
            cell.AcceptButton.setTitle("Pending", for: .normal)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    
}
