//
//  AddAddressModel.swift
//  Petcare
//
//  Created by SAIL on 31/10/23.
//

import Foundation

// MARK: - Welcome
struct AddAddressJson: Codable {
    var status, message: String?
}
