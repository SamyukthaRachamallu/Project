//
//  servicetypeModel.swift
//  Petcare
//
//  Created by SAIL on 28/10/23.
//
// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct Servicetype: Codable {
    var data: [type]?
}

// MARK: - Datum
struct type: Codable {
    var serviceID: Int?
        var petType, service, type: String?
        var amount, rating: Int?
        var info, image, imageType: String?

        enum CodingKeys: String, CodingKey {
            case serviceID = "ServiceID"
            case petType = "PetType"
            case service = "Service"
            case type = "Type"
            case amount = "Amount"
            case rating = "Rating"
            case info = "Info"
            case image = "Image"
            case imageType = "Image_type"
        }
    }
    


