//
//  HomeVC.swift
//  Petcare
//
//  Created by SAIL L1 on 27/09/23.
//

import UIKit

class HomeVC: UIViewController {
    
    let userDefault = UserDefaults.standard
    var pass: Home!
    
    @IBOutlet weak var Name: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        UserDefaultsManager.shared.savePetType("Dog")

    }
    override func viewWillAppear(_ animated: Bool) {
        UserDefaultsManager.shared.savePetType("Dog")
        getProfileAPI()
    }
    
    @IBAction func notificationAction(_ sender: Any) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "BookingsVC") as! BookingsVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "BookingsVC") as! BookingsVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
    
    @IBAction func veterinaryAction(_ sender: Any) {
        UserDefaultsManager.shared.saveType("Veterinary")
        UserDefaultsManager.shared.savePetType("Dog")
//        let vc = storyboard?.instantiateViewController(withIdentifier: "StoresVC") as! StoresVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "StoresVC") as! StoresVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
    @IBAction func trainingAction(_ sender: Any) {
        UserDefaultsManager.shared.saveType("Training")
//        let vc = storyboard?.instantiateViewController(withIdentifier: "StoresVC") as! StoresVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "StoresVC") as! StoresVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
    @IBAction func grooming(_ sender: Any) {
        UserDefaultsManager.shared.saveType("Grooming")
//        let vc = storyboard?.instantiateViewController(withIdentifier: "StoresVC") as! StoresVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "StoresVC") as! StoresVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
    @IBAction func walkingButton(_ sender: Any) {
        UserDefaultsManager.shared.saveType("Walking")
        UserDefaultsManager.shared.savePetType("Dog")
//        let vc = storyboard?.instantiateViewController(withIdentifier: "StoresVC") as! StoresVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "StoresVC") as! StoresVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    func getProfileAPI() {
        APIHandler().getAPIValues(type: Home.self, apiUrl: Constants.serviceType.HomeAPI, method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data ?? "")
                DispatchQueue.main.async {
                    self.Name.text = "What are you looking for, \(self.pass.data?.first?.userName ?? "")?"
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            }
        }
    }
}

