//
//  AddressModel.swift
//  Petcare
//
//  Created by SAIL on 31/10/23.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct Address: Codable {
    var data: [address]?
}

// MARK: - Datum
struct address: Codable {
       var userID, username, address: String?

        enum CodingKeys: String, CodingKey {
            case userID = "user_id"
            case username, address
        }
    }



