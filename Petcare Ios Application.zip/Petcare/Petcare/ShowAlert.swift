//
//  ShowAlert.swift
//  Petcare
//
//  Created by SAIL on 16/10/23.
//

import Foundation
import UIKit

extension UIViewController {
    func popUpAlert(title: String, message: String, actionTitles: [String], actionStyle: [UIAlertAction.Style], action: @escaping ([UIAlertAction]) -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        var alertActions = [UIAlertAction]()
        for (index, actionTitle) in actionTitles.enumerated() {
            let action = UIAlertAction(title: actionTitle, style: actionStyle[index], handler: { _ in
                action(alertActions)
            })
            alertActions.append(action)
            alertController.addAction(action)
        }
        
        present(alertController, animated: true, completion: nil)
    }
}
