//
//  PetVC.swift
//  Petcare
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class PetVC: UIViewController {
    @IBOutlet weak var PetName: UITextField!
    @IBOutlet weak var Breed: UITextField!
    
    @IBOutlet weak var Birthday: UITextField!
    
    @IBOutlet weak var dogLabel: UILabel!
    @IBOutlet weak var catLabel: UILabel!
    
    @IBOutlet weak var maleButton: UIButton!
    @IBOutlet weak var femaleButton: UIButton!
    
    @IBOutlet weak var dogView: UIView!
    @IBOutlet weak var catView: UIView!
    
    var pettype: String = UserDefaultsManager.shared.getPetType() ?? ""
    var gender: String = UserDefaultsManager.shared.getgender() ?? ""
    var userid: String = UserDefaultsManager.shared.getID()
    
    var pass: AddingpetJson!
    
    let datePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .wheels
        
        Birthday.inputView = datePicker
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(doneButtonPressed))
        toolbar.setItems([doneButton], animated: true)
        
        Birthday.inputAccessoryView = toolbar
        
        datePicker.addTarget(self, action: #selector(dateChanged), for: .valueChanged)
    }
    
    @objc func doneButtonPressed() {
        let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            Birthday.text = dateFormatter.string(from: datePicker.date)
            Birthday.resignFirstResponder()
    }
    
    @objc func dateChanged() {
        // Handle date changes if needed
    }
    
    @IBAction func backAction(_ sender: Any) {
//        self.navigationController?.popViewController(animated: true)
        dismiss(animated: true)
    }
    
    @IBAction func dogButtonAction(_ sender: Any) {
        UserDefaultsManager.shared.savePetType("Dog")
        self.dogView.backgroundColor = UIColor(red: 27/255.0, green: 55/255.0, blue: 158/255.0, alpha: 1)
        print("dog")
    }
    
    @IBAction func catButtonAction(_ sender: Any) {
        UserDefaultsManager.shared.savePetType("Cat")
        self.catView.backgroundColor = UIColor(red: 27/255.0, green: 55/255.0, blue: 158/255.0, alpha: 1)
        print("cat")
    }
    
    @IBAction func maleButtonActioon(_ sender: Any) {
        UserDefaultsManager.shared.savegender("Male")
        self.maleButton.backgroundColor = UIColor(red: 27/255.0, green: 55/255.0, blue: 158/255.0, alpha: 1)
        print("male")
    }
    
    @IBAction func femaleButtonAction(_ sender: Any) {
        UserDefaultsManager.shared.savegender("Female")
        self.femaleButton.backgroundColor = UIColor(red: 27/255.0, green: 55/255.0, blue: 158/255.0, alpha: 1)
        print("female")
    }
    
    @IBAction func DoneAction(_ sender: Any) {
        AddingpetAPI()
    }
    
    
    
    func AddingpetAPI() {
        
        
        let formData: [String: String] = [
            "petname": PetName.text ?? "",
            "breed": Breed.text ?? "",
            "birthday": Birthday.text ?? "",
            "pettype": pettype,
            "petgender": gender,
            "userID": userid
            
            /*"Designation": designationTextField.text ?? "",
             "contact_no": numberTextField.text ?? "",
             "Address": AddressTextField.text ?? "",
             "blood_group": bloodgroupTextField.text ?? ""*/
            
        ]
        APIHandler().postAPIValues(type: AddingpetJson.self, apiUrl: Constants.serviceType.AddingpetAPI.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissPresentAlert(title: "Added", message: "Pet added successfully", viewController: self, duration: 2.0)
//                    AlertManager.showAutoDismissAlert(title: "Added", message: "Pet added successfully", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
}




/*
 // MARK: - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
 // Get the new view controller using segue.destination.
 // Pass the selected object to the new view controller.
 }
 */


