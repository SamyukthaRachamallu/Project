//
//  NotificationVC.swift
//  Petcare
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class NotificationVC: UIViewController {
    
    @IBOutlet weak var notificationTableView: UITableView!
    var pass: Request!
//    var userId : String = UserDefaultsManager.shared.getID()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.notificationTableView.delegate = self
        self.notificationTableView.dataSource = self
        //        self.notificationTableView.register(UINib(nibName: "NotificationTableViewCell", bundle: nil), forCellReuseIdentifier: "NotificationTableViewCell")
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        RequestAPI()
    }
    
    func RequestAPI() {
        APIHandler.shared.getAPIValues(type: Request.self, apiUrl: Constants.serviceType.RequestAPI,method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.pass = data
                print(self.pass.data ?? "")
                DispatchQueue.main.async {
                    self.notificationTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}

extension NotificationVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pass?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationTableViewCell", for: indexPath) as! NotificationTableViewCell
        
        cell.ConfrimButton.tag = indexPath.row
        cell.ConfrimButton.addTarget(self, action: #selector(acceptButton(sender:)), for: .touchUpInside)
        cell.CancelButton.tag = indexPath.row
        cell.CancelButton.addTarget(self, action: #selector(rejectButton(sender:)), for: .touchUpInside)
        
        if let data = self.pass?.data, indexPath.row < data.count {
            let detail = data[indexPath.row]
            
            cell.BookingID.text = "bookingID: \(detail.bookingID ?? "")"
            cell.Service.text = "service: \(detail.service ?? "")"
            cell.Address.text = "pickupAddress: \(detail.pickupAddress ?? "")"
            cell.AppointmentDate.text = "appointmentDate: \(detail.appointmentDate  ?? "")"
        } else {
            cell.BookingID.text = "No Data"
            cell.Service.text = ""
            cell.Address.text = ""
            cell.AppointmentDate.text = ""
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    @objc func acceptButton(sender: UIButton) {
        let rowToRemove = sender.tag
        guard let bookingId = self.pass.data?[rowToRemove].bookingID else {
            return
        }
        guard let appoinmentDate = self.pass.data?[rowToRemove].appointmentDate else {
            return
        }
        guard let userID = self.pass.data?[rowToRemove].userID else {
            return
        }
        
        if let bookingIndex = self.pass.data?.firstIndex(where: { $0.bookingID == bookingId }),
           let appointmentIndex = self.pass.data?.firstIndex(where: { $0.appointmentDate == appoinmentDate }),
            let userIndex = self.pass.data?.firstIndex(where: { $0.userID == userID })
        {
            
            if bookingIndex == appointmentIndex && bookingIndex == userIndex{
                // Remove the item at the common index
                self.pass.data?.remove(at: bookingIndex)
                self.RequestAPI()
            }
            self.notificationTableView.reloadData()
            let formData: [String: String] = [
                "BookingID": String(bookingId),
                "AppointmentDate": appoinmentDate,
                "UserID": String(userID)
            ]
            APIHandler().postAPIValues(type: ConfrimJson.self, apiUrl: Constants.serviceType.ConfrimAPI.rawValue, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        self.RequestAPI()
                    }
                case .failure(let error):
                    print("Error: \(error)")
                    // Handle error 
                }
            }
        }
    }
    @objc func rejectButton(sender: UIButton) {
           let rowToRemove = sender.tag

           guard let bookingId = self.pass.data?[rowToRemove].bookingID else {
               return
           }

           guard let appoinmentDate = self.pass.data?[rowToRemove].appointmentDate  else {
               return
           }
        guard let userID = self.pass.data?[rowToRemove].userID else {
            return
        }
        
        if let bookingIndex = self.pass.data?.firstIndex(where: { $0.bookingID == bookingId }),
           let appointmentIndex = self.pass.data?.firstIndex(where: { $0.appointmentDate == appoinmentDate }),
            let userIndex = self.pass.data?.firstIndex(where: { $0.userID == userID })
         {
            if bookingIndex == appointmentIndex && bookingIndex == userIndex{
                // Remove the item at the common index
                self.pass.data?.remove(at: bookingIndex)
                self.RequestAPI()
            }
            self.notificationTableView.reloadData()
            let formData: [String: String] = [
                "BookingID": String(bookingId),
                "AppointmentDate": appoinmentDate,
                "UserID": String(userID)
            ]
           APIHandler().postAPIValues(type: CancelJson.self, apiUrl: Constants.serviceType.CancelAPI.rawValue, method: "POST", formData: formData) { result in
               switch result {
               case .success(let response):
                   print("Status: \(response.status ?? "")")
                   print("Message: \(response.message)")
                   DispatchQueue.main.async {
                       self.RequestAPI()
                   }
               case .failure(let error):
                   print("Error: \(error)")
                   // Handle error
               }
           }
       }
   }
    
    
}

