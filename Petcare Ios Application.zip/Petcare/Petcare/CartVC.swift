//
//  CartVC.swift
//  Petcare
//
//  Created by SAIL on 09/10/23.
//

import UIKit
import Razorpay

class CartVC: UIViewController {
    
    
    @IBOutlet weak var Heading: UILabel!
    @IBOutlet weak var itemtotal: UILabel!
    @IBOutlet weak var total: UILabel!
    @IBOutlet weak var amount: UILabel!
    @IBOutlet weak var labeltitle: UILabel!
    @IBOutlet weak var Address: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    var pass: Cart!
    var receiver: [String: Any] = [String: Any]()
    
    var userId = UserDefaultsManager.shared.getID()
    var service : String = UserDefaultsManager.shared.getType() ?? ""
    var type : String = UserDefaultsManager.shared.gettype() ?? ""
    var appoinmentDate : String = UserDefaultsManager.shared.getDate() ?? ""
    var appointmentTime : String = UserDefaultsManager.shared.getTime() ?? ""
    var amounts : String = UserDefaultsManager.shared.getAmount() ?? ""
    var address : String = UserDefaultsManager.shared.getAddress() ?? ""
    
    let razorpayTestKey = "rzp_test_CPgJvkClvfmATv"
    var razorpay: RazorpayCheckout!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        razorpay = RazorpayCheckout.initWithKey(razorpayTestKey, andDelegate: self)
        
        self.Heading.text = "\(self.type)"
        self.labeltitle.text = "\(self.type)"
        self.amount.text = " ₹ \(self.amounts)"
        self.itemtotal.text = " ₹ \(self.amounts)"
        self.total.text = " ₹ \(self.amounts)"
        
        self.Address.text = "\(self.receiver["Address"] ?? "")"
        UserDefaultsManager.shared.saveAddress("\(self.receiver["Address"] ?? "")")
        UserDefaultsManagers.shared.setValue("\(self.receiver["Address"] ?? "")", forKey: "Address")
        self.nameLabel.text = "\(self.receiver["Username"] ?? "")"
        UserDefaultsManagers.shared.setValue("\(self.receiver["Username"] ?? "")", forKey: "Username")
        
        // Do any additional setup after loading the view.
    }
    
    internal func showPaymentForm(){
        let options: [String:Any] = [
            "amount": "\(self.amounts)00", //This is in currency subunits. 100 = 100 paise= INR 1.
            "currency": "INR",//We support more that 92 international currencies.
            "description": "", //purchase description
            "order_id": "", //order_DBJOWzybf0sJbb
            "image": "", //
            "name": "\(self.type)",
            "prefill": [
                "contact": "9797979797",
                "email": "foo@bar.com"
            ],
            "theme": [
                "color": "#F9D3D3"
            ]
        ]
        razorpay.open(options, displayController: self)
    }
    
    @IBAction func editAction(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func backAction(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func AddAddressAction(_ sender: Any) {
                
        self.showPaymentForm()
    }
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    func BookingAPI() {
        let formData: [String: String] = [
            "PetID": "4",
            "UserID": userId,
            "Service": service,
            "Type": type,
            "AppointmentDate": appoinmentDate,
            "AppointmentTime": appoinmentDate,
            "Amount": amounts,
            "PickupAddress": address
        ]
        APIHandler().postAPIValues(type: DateJson.self, apiUrl: Constants.serviceType.BookingAPI.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    print(formData)
                    //                    AlertManager.showCustomAlert(title: "Added", message: "Product added to cart. Do you continue your payment now?", viewController: self, okButtonTitle: "Go to Payment", cancelButtonTitle: "Later", cancelHandler: {
//                    })
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
}

extension CartVC : RazorpayPaymentCompletionProtocol {
    
    func onPaymentError(_ code: Int32, description str: String) {
        print("error: ", code, str)
        //        self.presentAlert(withTitle: "Alert", message: str)
        AlertManager.showAlert(title: "Alert", message: str, viewController: self)
        //        AlertManager.showAutoDismissAlert(title: "Alert", message: str, viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }
    
    func onPaymentSuccess(_ payment_id: String) {
        print("success: ", payment_id)
        //        self.presentAlert(withTitle: "Success", message: "Payment Succeeded")
        AlertManager.showAlert(title: "Success", message: "Payment Succeeded", viewController: self, completionHandler: {
            self.BookingAPI()
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyboard.instantiateViewController(withIdentifier: "InitialTabBar") as! InitialTabBar
            viewController.providesPresentationContextTransitionStyle = true
            viewController.definesPresentationContext = true
            viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
            self.present(viewController, animated: true)
        })
            // In ViewControllerA
//            let viewController = self.storyboard?.instantiateViewController(withIdentifier: "InitialTabBar") as! InitialTabBar
//
//            self.dismiss(animated: true) {
//                // Present ViewControllerB after the dismissal animation completes
//                self.present(viewController, animated: true, completion: nil)
//            }

        
        //        AlertManager.showAutoDismissAlert(title: "Success", message: "Payment Succeeded", viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }
}

extension CartVC: RazorpayPaymentCompletionProtocolWithData {
    
    func onPaymentError(_ code: Int32, description str: String, andData response: [AnyHashable : Any]?) {
        print("error: ", code)
        //        self.presentAlert(withTitle: "Alert", message: str)
        AlertManager.showAlert(title: "Alert", message: str, viewController: self)
        //        AlertManager.showAutoDismissAlert(title: "Alert", message: str, viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }
    
    func onPaymentSuccess(_ payment_id: String, andData response: [AnyHashable : Any]?) {
        print("success: ", payment_id)
        //        self.presentAlert(withTitle: "Success", message: "Payment Succeeded")
        AlertManager.showAlert(title: "Success", message: "Payment Succeeded", viewController: self, completionHandler: {
            self.BookingAPI()
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyboard.instantiateViewController(withIdentifier: "InitialTabBar") as! InitialTabBar
            viewController.providesPresentationContextTransitionStyle = true
            viewController.definesPresentationContext = true
            viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
            self.present(viewController, animated: true)
        })
            // In ViewControllerA
//            let viewController = self.storyboard?.instantiateViewController(withIdentifier: "InitialTabBar") as! InitialTabBar
//
//            self.dismiss(animated: true) {
//                // Present ViewControllerB after the dismissal animation completes
//                self.present(viewController, animated: true, completion: nil)
//            }
            
        
        //        AlertManager.showAutoDismissAlert(title: "Success", message: "Payment Succeeded", viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }
}

