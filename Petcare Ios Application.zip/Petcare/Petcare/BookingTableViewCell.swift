//
//  BookingTableViewCell.swift
//  Petcare
//
//  Created by SAIL on 01/11/23.
//

import UIKit

class BookingTableViewCell: UITableViewCell {
    
    @IBOutlet weak var BookingID: UILabel!
    @IBOutlet weak var Service: UILabel!
    @IBOutlet weak var Address: UILabel!
    
    @IBOutlet weak var AcceptButton: UIButton!
    @IBOutlet weak var AppoinmentDate: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
