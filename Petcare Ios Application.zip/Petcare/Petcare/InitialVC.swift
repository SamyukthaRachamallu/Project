//
//  InitialVC.swift
//  Petcare
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class InitialVC: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descripLabel: UILabel!
    @IBOutlet weak var pageControl: UIPageControl!
    
    var count: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        pageControl.pageIndicatorTintColor = .lightGray
        pageControl.currentPageIndicatorTintColor = .yellow
    }
    
    @IBAction func nextButtonAction(_ sender: Any) {
        count += 1
        
        if count == 1 {
            titleLabel.text = "Proven Experts"
            descripLabel.text = "We interview every specialist before they get to work"
            pageControl.currentPage = 1
        } else if count == 2 {
            titleLabel.text = "Reliable Reviews"
            descripLabel.text = "A review can be left only by a user who used the service"
            pageControl.currentPage = 2
        } else if count == 3 {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let viewController = storyboard.instantiateViewController(withIdentifier: "SelectionVC") as! SelectionVC
            viewController.providesPresentationContextTransitionStyle = true
            viewController.definesPresentationContext = true
            viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
            self.present(viewController, animated: true)
        }
    }
    
}
