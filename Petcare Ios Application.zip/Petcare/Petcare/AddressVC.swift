//
//  AddressVC.swift
//  Petcare
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class AddressVC: UIViewController {
    
  
    @IBOutlet weak var addressTableView: UITableView!
    var pass: Address!
    
    var sender: [String:Any] = [String:Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.addressTableView.delegate = self
        self.addressTableView.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    @IBAction func closeAction(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func addAddressAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "AddAddressVC") as! AddAddressVC
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        AddressAPI()
    }
    
    func AddressAPI() {
        APIHandler().getAPIValues(type: Address.self, apiUrl: Constants.serviceType.AddressAPI, method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data ?? "")
                DispatchQueue.main.async {
                    self.addressTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            }
        }
    }
    
}

extension AddressVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.pass?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "addressTableViewCell", for: indexPath) as! addressTableViewCell
        
        if let details = self.pass?.data?[indexPath.row] {
            cell.Address.text = "\(details.address ?? "" )"
            cell.UserName.text = "\(details.username ?? "" )"
        } else {
            cell.Address.text = "Nil"
            cell.UserName.text = "Nil"
        }
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "CartVC") as! CartVC
        
        if let detail = self.pass?.data?[indexPath.row] {
            self.sender = ["Address":detail.address ?? "", "Username":detail.username ?? ""]
        }
        
        vc.receiver = self.sender
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
        
    }
    
}
