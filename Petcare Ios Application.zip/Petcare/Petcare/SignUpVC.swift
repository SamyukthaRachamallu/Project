//
//  SignUpVC.swift
//  Petcare
//
//  Created by SAIL L1 on 27/09/23.
//

import UIKit

class SignUpVC: UIViewController {
    @IBOutlet weak var Name: UITextField!
    @IBOutlet weak var Number: UITextField!
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        Password.isSecureTextEntry = true
    }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        dismiss(animated: true)
    }
    
    func isValidEmailAddress(emailAddressString: String) -> Bool {
            
            var returnValue = true
            let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
            
            do {
                let regex = try NSRegularExpression(pattern: emailRegEx)
                let nsString = emailAddressString as NSString
                let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
                
                if results.count == 0
                {
                    returnValue = false
                }
                
            } catch let error as NSError {
                print("invalid regex: \(error.localizedDescription)")
                returnValue = false
            }
            
            return  returnValue
        }
    
    @IBAction func signUpButtonAction(_ sender: Any) {
        if Name.text == "" && Password.text == "" && Email.text == "" && Number.text == "" {
            popUpAlert(title: "Alert", message: "Please Enter all Values", actionTitles: ["OK"], actionStyle: [UIAlertAction.Style.default]) { actions in
                if actions[0].style == .default {
                    print("Ok button tapped")
                    
                }
            }
        }
        else if isValidEmailAddress(emailAddressString: Email.text ?? "") != true{
//            let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "InitialTabBar") as! InitialTabBar
//            self.navigationController?.pushViewController(nextVc, animated: true)
            AlertManager.showAlert(title: "Error", message: "Invalid email", viewController: self)
            
        } else {
            registerUser()
        }
    
    }
    
func registerUser() {
    let formData: [String: String] = [
        "Name": Name.text ?? "",
        "PhoneNumber": Number.text ?? "",
        "Email": Email.text ?? "",
        "Password": Password.text ?? ""
    ]
    APIHandler().postAPIValues(type: SignupJson.self, apiUrl: Constants.serviceType.Signupurl.rawValue, method: "POST", formData: formData) { result in
        switch result {
        case .success(let response):
            print("Status: \(response.status)")
            print("Message: \(response.message)")
            DispatchQueue.main.async {
                self.popUpAlert(title: "Success", message: "Sign UP Successfull!", actionTitles: ["OK"], actionStyle: [UIAlertAction.Style.default]) { actions in
                    let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
//                    self.navigationController?.pushViewController(nextVC, animated: true)
                    nextVC.modalPresentationStyle = .fullScreen
                    self.present(nextVC, animated: true)
                }
               
            }
        case .failure(let error):
            print("Error: \(error)")
        }
    }
}
}

