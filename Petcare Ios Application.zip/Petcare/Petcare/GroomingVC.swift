//
//  GroomingVC.swift
//  Petcare
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class GroomingVC: UIViewController {

    @IBOutlet weak var GroomingTableView: UITableView!
       
    @IBOutlet weak var addServiceButton: UIButton!
    var pass: Gromming!
    override func viewDidLoad() {
        super.viewDidLoad()
        
                self.GroomingTableView.delegate = self
                self.GroomingTableView.dataSource = self
                self.GroomingTableView.register(UINib(nibName: "ServiceTableViewCell", bundle: nil), forCellReuseIdentifier: "ServiceTableViewCell")
        if UserDefaultsManager.shared.getUserProfile() == "2"{
            addServiceButton.isHidden = true
        } else {
            addServiceButton.isHidden = false
        }
        }
    
    @IBAction func backAction(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        dismiss(animated: true)
    }
    
    @IBAction func addServiceAction(_ sender: Any) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "AddserviceVC") as! AddServiceVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "AddServiceVC") as! AddServiceVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
       GrommingAPI()
    }
    
    func GrommingAPI() {
        APIHandler.shared.getAPIValues(type: Gromming.self, apiUrl: Constants.serviceType.GrommingAPI.rawValue ,method:"GET") { result in
                switch result {
                case .success(let data):
                    print(data)
                    self.pass = data
                    print(self.pass.data ?? "")
                    DispatchQueue.main.async {
                        self.GroomingTableView.reloadData()
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async{
                        
                    }
                
                }
            }
        }
    
}

extension GroomingVC: UITableViewDelegate, UITableViewDataSource {
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.pass?.data?.count ?? 1
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "ServiceTableViewCell", for: indexPath) as! ServiceTableViewCell
    cell.Delete.tag = indexPath.row
    cell.Delete.addTarget(self, action: #selector(acceptButton(sender:)), for: .touchUpInside)
   
    if let detail = self.pass?.data?[indexPath.row] {
        cell.Service.text = "Service   : \(detail.service ?? "")"
        cell.SubCategory.text = "Type   : \(detail.type ?? "")"
        cell.PetType.text = "PetType    : \(detail.petType ?? "")"
        cell.Price.text = "Amount   : \(detail.amount  ?? "")"
    } else {
        cell.Service.text = "No Data"
        cell.SubCategory.text = ""
        cell.PetType.text = ""
        cell.Price.text = ""
    }
return cell
}

func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
return 130
}
    @objc func acceptButton(sender: UIButton) {
        let rowToRemove = sender.tag
        guard let serviceID = self.pass.data?[rowToRemove].serviceID else {
            return
        }
        
//        if let serviceIndex = self.pass.data?.firstIndex(where: { $0.serviceID == serviceID })
//
//        {
            
            //            if bookingIndex == appointmentIndex && bookingIndex == userIndex{
            //                // Remove the item at the common index
            //                self.pass.data?.remove(at: bookingIndex)
            //                self.RequestAPI()
            //            }
            self.GrommingAPI()
            self.GroomingTableView.reloadData()
            let formData: [String: String] = [
                "ServiceID": String(serviceID),
                
            ]
            APIHandler().postAPIValues(type: DeleteJson.self, apiUrl: Constants.serviceType.DeleteAPI.rawValue, method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        self.GrommingAPI()
                    }
                case .failure(let error):
                    print("Error: \(error)")
                    // Handle error
                }
            }
        }
    }

