//
//  DashboardVC.swift
//  Petcare
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class DashboardVC: UIViewController {
    
    @IBOutlet weak var notificationView: UIView!
    @IBOutlet weak var segmentControll: UISegmentedControl!
    
    var confirm : ConfirmationModel!
    var cancel: CancelledModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        notificationView.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    @IBAction func segmentControlAction(_ sender: Any) {
        if segmentControll.selectedSegmentIndex == 0 {
            notificationView.isHidden = true
        } else {
            notificationView.isHidden = false
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
//        for controller in self.navigationController!.viewControllers as Array {
//            if controller.isKind(of: SelectionVC.self) {
//                self.navigationController!.popToViewController(controller, animated: true)
//                break
//            }
//        }
        dismiss(animated: true)
    }
    
    @IBAction func serviceListAction(_ sender: Any) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "ServiceListVC") as! ServiceListVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "ServiceListVC") as! ServiceListVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
        
    }
    
    @IBAction func categoriesAction(_ sender: Any) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "CategoriesVC") as! CategoriesVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "CategoriesVC") as! CategoriesVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
    @IBAction func conformedAction(_ sender: Any) {
        self.getConfirmAPI()
    }
    
    @IBAction func cancelledAction(_ sender: Any) {
        self.getCancelAPI()
    }
    
    func getConfirmAPI() {
        APIHandler().getAPIValues(type: ConfirmationModel.self, apiUrl: Constants.serviceType.ConfirmedCount.rawValue, method: "GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.confirm = data
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Confirmed", message: "\(self.confirm.data?.first?.confirmedBookingsCount ?? "") products is confirmed", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(alert, animated: true)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func getCancelAPI() {
        APIHandler().getAPIValues(type: CancelledModel.self, apiUrl: Constants.serviceType.CancelledCount.rawValue, method: "GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.cancel = data
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Canclled", message: "\(self.cancel.data?.first?.cancelledBookingsCount ?? "") products is Cancelled", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(alert, animated: true)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}
