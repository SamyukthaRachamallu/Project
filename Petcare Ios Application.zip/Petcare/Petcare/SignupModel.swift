//
//  SignupModel.swift
//  Petcare
//
//  Created by SAIL on 16/10/23.
//
import Foundation

// MARK: - Welcome
struct SignupJson: Codable {
    var status, message: String?
}

