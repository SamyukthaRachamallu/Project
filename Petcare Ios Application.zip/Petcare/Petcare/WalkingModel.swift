//
//  WalkingModel.swift
//  Petcare
//
//  Created by SAIL on 19/10/23.
import Foundation

// MARK: - Welcome
struct Walking: Codable {
    var data: [Walk]?
}

// MARK: - Datum
struct Walk: Codable {
    var service, type, petType, amount: String?
     var serviceID: String?

     enum CodingKeys: String, CodingKey {
         case service = "Service"
         case type = "Type"
         case petType = "PetType"
         case amount = "Amount"
         case serviceID = "ServiceID"
     }
 }

