//
//  AddServiceVC.swift
//  Petcare
//
//  Created by SAIL on 19/10/23.
//

import UIKit

class AddServiceVC: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource, UITextFieldDelegate {
    
    @IBOutlet weak var service: UITextField!
    @IBOutlet weak var Subcategory: UITextField!
    @IBOutlet weak var Pettype: UITextField!
    @IBOutlet weak var Price: UITextField!
    
    let pickerView1 = UIPickerView()
    let pickerView2 = UIPickerView()
    
    let serviceData = ["Veterinary", "Training", "Grooming", "Walking"]
    let pet = ["Dog", "Cat"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        pickerView1.delegate = self
        pickerView1.dataSource = self
        
        pickerView2.delegate = self
        pickerView2.dataSource = self
        
        service.inputView = pickerView1
        service.delegate = self
//        service.resignFirstResponder()
        
        Pettype.inputView = pickerView2
        Pettype.delegate = self
//        service.resignFirstResponder()
        
        // Add a toolbar with a "Done" button to dismiss the picker
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonPressed))
        toolbar.setItems([doneButton], animated: true)
        
        service.inputAccessoryView = toolbar
        Pettype.inputAccessoryView = toolbar
        
    }
    
    func registerUser() {
        let formData: [String: String] = [
            "service_name": service.text ?? "",
            "subcategory": Subcategory.text ?? "",
            "pet_type": Pettype.text ?? "",
            "price": Price.text ?? ""
        ]
        APIHandler().postAPIValues(type: Addservice.self, apiUrl: Constants.serviceType.AddserviceAPI.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissPresentAlert(title: "Added", message: "Service Added Successfully", viewController: self, duration: 2.0)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func addservicebutton(_ sender: Any) {
        registerUser()
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == pickerView1 {
            return serviceData.count
        } else if pickerView == pickerView2 {
            return pet.count
        }
        return 0
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == pickerView1 {
            return serviceData[row]
        } else if pickerView == pickerView2 {
            return pet[row]
        }
        return nil
    }

    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
//        if pickerView == pickerView1 {
//            service.text = serviceData[row]
//        } else if pickerView == pickerView2 {
//            Pettype.text = pet[row]
//        }
    }

        

    // MARK: - UITextFieldDelegate method

    func textFieldDidBeginEditing(_ textField: UITextField) {
        // You can perform any additional actions when the text field begins editing
    }

    // MARK: - Helper method for "Done" button

    @objc func doneButtonPressed() {
        if service.isFirstResponder {
            service.text = pickerView1.selectedRow(inComponent: 0) < serviceData.count ? serviceData[pickerView1.selectedRow(inComponent: 0)] : ""
            service.resignFirstResponder()
        } else if Pettype.isFirstResponder {
            Pettype.text = pickerView2.selectedRow(inComponent: 0) < pet.count ? pet[pickerView2.selectedRow(inComponent: 0)] : ""
            Pettype.resignFirstResponder()
        }
    }


}





