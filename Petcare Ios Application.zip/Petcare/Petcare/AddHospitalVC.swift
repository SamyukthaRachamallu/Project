//
//  AddHospitalVC.swift
//  Petcare
//
//  Created by Charan on 18/12/23.
//

import UIKit

class AddHospitalVC: UIViewController {

    @IBOutlet weak var HospitalTF: UITextField!
    @IBOutlet weak var HospitalNameTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func BackButtonAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    @IBAction func AddButtonAction(_ sender: Any) {
        AddHospital() 
    }
    
    func AddHospital() {
        let formData: [String: String] = [
            "hospitalId": HospitalTF.text ?? "",
            "hospitalName": HospitalNameTF.text ?? ""
            
        ]
        APIHandler().postAPIValues(type: AddHospitalJson.self, apiUrl: Constants.serviceType.AddHospitalAPI.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    AlertManager.showAutoDismissPresentAlert(title: "Added", message: "Hospital Added Successfully", viewController: self, duration: 2.0)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }

}
