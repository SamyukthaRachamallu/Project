//
//  DateModel.swift
//  Petcare
//
//  Created by SAIL on 28/10/23.
//

import Foundation

// MARK: - Welcome
struct DateJson: Codable {
    var status, message: String?
}
