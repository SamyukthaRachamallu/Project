//
//  CollectionViewCell.swift
//  Petcare
//
//  Created by SAIL L1 on 22/09/23.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var bookNow: UILabel!
    @IBOutlet weak var petName: UILabel!
}
