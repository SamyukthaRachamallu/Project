//
//  DogvaccinationVC.swift
//  Petcare
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class DogvaccinationVC: UIViewController {
    
    @IBOutlet weak var aboutStackView: UIStackView!
    @IBOutlet weak var infoView: UIView!
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var HowItWorksView: UIView!
    @IBOutlet weak var amount: UILabel!
    @IBOutlet weak var type: UILabel!
    @IBOutlet weak var titletype: UILabel!
    @IBOutlet weak var labeltype: UILabel!
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var howItWorksLabel: UILabel!
    @IBOutlet weak var imagess: UIImageView!
    
    var pass: Infopage!
    var receiver: [String:Any] = [String:Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        infoView.isHidden = true
        descriptionView.isHidden = true
        HowItWorksView.isHidden = true
        
        self.type.text = "\(self.receiver["Name"] ?? "")"
        UserDefaultsManagers.shared.setValue("\(self.receiver["Name"] ?? "")", forKey: "Name")
        self.titletype.text = "\(self.receiver["Title"] ?? "")"
        UserDefaultsManagers.shared.setValue("\(self.receiver["Title"] ?? "")", forKey: "Title")
        self.labeltype.text = "About \(self.receiver["Title"] ?? "")"
        self.amount.text = " ₹ \(self.receiver["Cost"] ?? "")"
        UserDefaultsManager.shared.saveAmount("\(self.receiver["Cost"] ?? "")")
        UserDefaultsManagers.shared.setValue("\(self.receiver["Cost"] ?? "")", forKey: "Cost")
        self.imagess.image = UIImage(named: "\(self.receiver["Image"] ?? "")")
        
        
        if UserDefaultsManager.shared.getPetType() == "Dog" {
            self.imagess.image = UIImage(named: "1")
        } else {
            self.imagess.image = UIImage(named: "2")
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
        dismiss(animated: true)
    }
    
    @IBAction func infoDropDownAction(_ sender: Any) {
        infoView.isHidden = !infoView.isHidden
        
        if infoView.isHidden {
            infoView.isHidden = true
        } else {
            infoView.isHidden = false
        }
        
        infoView.setContentHuggingPriority(infoView.isHidden ? .defaultLow : .defaultHigh, for: .vertical)
        infoView.setContentCompressionResistancePriority(infoView.isHidden ? .defaultLow : .defaultHigh, for: .vertical)
        
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    
    @IBAction func descriptionDropDownAction(_ sender: Any) {
        descriptionView.isHidden = !descriptionView.isHidden
        
        if descriptionView.isHidden {
            descriptionView.isHidden = true
        } else {
            descriptionView.isHidden = false
        }
        
        descriptionView.setContentHuggingPriority(descriptionView.isHidden ? .defaultLow : .defaultHigh, for: .vertical)
        descriptionView.setContentCompressionResistancePriority(descriptionView.isHidden ? .defaultLow : .defaultHigh, for: .vertical)
        
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    
    @IBAction func howItWorksDropDownAction(_ sender: Any) {
        HowItWorksView.isHidden = !HowItWorksView.isHidden
        
        if HowItWorksView.isHidden {
            HowItWorksView.isHidden = true
        } else {
            HowItWorksView.isHidden = false
        }
        
        HowItWorksView.setContentHuggingPriority(HowItWorksView.isHidden ? .defaultLow : .defaultHigh, for: .vertical)
        HowItWorksView.setContentCompressionResistancePriority(HowItWorksView.isHidden ? .defaultLow : .defaultHigh, for: .vertical)
        
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    
    @IBAction func addCardAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "ScheduleVC") as! ScheduleVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
        viewController.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
        //        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        //                let viewController = storyboard.instantiateViewController(withIdentifier: "ScheduleVC") as! ScheduleVC
        //
        //                if let presentationController = viewController.presentationController as? UISheetPresentationController {
        //                    presentationController.detents = [.medium()] /// change to [.medium(), .large()] for a half *and* full screen sheet
        //                }
        //
        //                self.present(viewController, animated: true)
        //            }
    }
    override func viewWillAppear(_ animated: Bool) {
        InfoAPI()
    }
    
    func InfoAPI() {
        APIHandler().getAPIValues(type: Infopage.self, apiUrl: Constants.serviceType.InfoAPI, method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data ?? "")
                
                DispatchQueue.main.async {
                    self.infoLabel.text = self.pass?.data?.first?.info
                    self.descriptionLabel.text = self.pass?.data?.first?.info
                    self.howItWorksLabel.text = self.pass?.data?.first?.info
//                    self.amount.text = self.pass.data?.first?.amount
//                    self.type.text = self.pass.data?.first?.type
//                    self.titletype.text = self.pass.data?.first?.type
//                    self.labeltype.text = self.pass.data?.first?.type
                    
                    
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            }
        }
    }
}
    
