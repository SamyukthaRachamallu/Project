//
//  HospitalModel.swift
//  Petcare
//
//  Created by Charan on 18/12/23.
//

import Foundation

// MARK: - Request
struct Hospital: Codable {
    var data: [hospitall]?
}

// MARK: - Datum
struct hospitall: Codable {
    var designationID, title: String?

    enum CodingKeys: String, CodingKey {
        case designationID = "DesignationID"
        case title = "Title"
    }
}
