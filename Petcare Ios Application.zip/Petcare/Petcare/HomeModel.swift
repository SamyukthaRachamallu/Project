//
//  HomeModel.swift
//  Petcare
//
//  Created by SAIL on 17/10/23.
//

import Foundation

// MARK: - Welcome
struct Home: Codable {
    var status: Bool?
    var message: String?
    var data: [DataClass]?
}

// MARK: - DataClass
struct DataClass: Codable {
    var userName, isAdmin: String?
    var cartItems: Int?

    enum CodingKeys: String, CodingKey {
        case userName = "UserName"
        case isAdmin, cartItems
    }
}

