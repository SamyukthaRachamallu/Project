//
//  SelectpetVC.swift
//  Petcare
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class SelectpetVC: UIViewController {

    @IBOutlet weak var SelectTableView: UITableView!
    var selectedIndexPaths: [IndexPath] = []
    var Name = String()
    var pass: Selectpet!
    var selectedIndexPath : IndexPath?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.SelectTableView.delegate = self
        self.SelectTableView.dataSource = self
        // Do any additional setup after loading the view. checkmark.circle.fill
    }
    
    @IBAction func closeAction(_ sender: Any) {
        dismiss(animated: true)
    }
    
    @IBAction func selectPetAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "AddressVC") as! AddressVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
        viewController.view.backgroundColor = UIColor.gray.withAlphaComponent(0.5)
    }
    override func viewWillAppear(_ animated: Bool) {
        SelectPetAPI()
    }
    
    func SelectPetAPI() {
        APIHandler.shared.getAPIValues(type: Selectpet.self, apiUrl: Constants.serviceType.SelectPetAPI,method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.pass = data
                print(self.pass.data ?? "")
                DispatchQueue.main.async {
                    self.SelectTableView.reloadData()
//                    UserDefaultsManager.shared.getUserId()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}
extension SelectpetVC: UITableViewDelegate, UITableViewDataSource {
    
  //  var selectedIndexPath: IndexPath? // Variable to store the currently selected index path

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.pass?.data?.count ?? 1
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SelectpetTableViewCell", for: indexPath) as! SelectpetTableViewCell

//        cell.selectButton.setImage(UIImage(systemName: "circle"), for: .normal)
//
//        if let selectedIndexPath = selectedIndexPath, selectedIndexPath == indexPath {
//            cell.selectButton.setImage(UIImage(systemName: "checkmark.circle.fill"), for: .normal)
//        }

        if let detail = self.pass?.data?[indexPath.row] {
            cell.PetName.text = " \(detail.petName ?? "")"
            cell.Breed.text = " \(detail.breed ?? "")"
        } else {
            cell.PetName.text = "Nil"
            cell.Breed.text = "Nil"
        }
        
        if selectedIndexPaths.contains(indexPath) {
            // Set the radioOn image for the selected state.
            cell.selectButton.setImage(UIImage(systemName: "checkmark.circle.fill"), for: .selected)
            Name = self.pass?.data?[indexPath.row].petName ?? "Nil"
            print(Name,"--->")
        } else {
            // Set the radioOff image for the normal state.
            cell.selectButton.setImage(UIImage(systemName: "circle"), for: .normal)
        }
        
        cell.selectButton.isSelected = selectedIndexPaths.contains(indexPath)
        
        cell.selectButton.addTarget(self, action: #selector(radioButtonTapped(_:)), for: .touchUpInside)
        
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }

//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        selectedIndexPath = indexPath // Update the selected index path
//            
//            if let cell = tableView.cellForRow(at: indexPath) as? SelectpetTableViewCell {
//                if cell.selectButton.isSelected {
//                    cell.selectButton.setImage(UIImage(systemName: "checkmark.circle.fill"), for: .normal)
//                } else {
//                    cell.selectButton.setImage(UIImage(systemName: "checkmark.circle"), for: .normal)
//                }
//            }
//            
//            tableView.reloadData()
//    }
    
    @objc func radioButtonTapped(_ sender: UIButton) {
        if let cell = sender.superview as? SelectpetTableViewCell, let indexPath = SelectTableView.indexPath(for: cell) {
            if selectedIndexPaths.contains(indexPath) {
                selectedIndexPaths.removeAll { $0 == indexPath }
            } else {
                selectedIndexPaths.append(indexPath)
            }
            SelectTableView.reloadData() // Reload the table view to update the cell appearance.
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // When a cell is selected, toggle its selection state and update the UI.
        if selectedIndexPaths.contains(indexPath) {
            selectedIndexPaths.removeAll { $0 == indexPath }
        } else {
            selectedIndexPaths.append(indexPath)
        }

        tableView.reloadData() // Reload the table view to update the cell appearance.
    }
}
