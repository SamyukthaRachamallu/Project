//
//  CancelledModel.swift
//  Petcare
//
//  Created by Haris Madhavan on 18/11/23.
//

import Foundation

// MARK: - CancelledModel
struct CancelledModel: Codable {
    var data: [Cancel]?
}

// MARK: - Datum
struct Cancel: Codable {
    var cancelledBookingsCount: String?

    enum CodingKeys: String, CodingKey {
        case cancelledBookingsCount = "cancelled_bookings_count"
    }
}
