//
//  UserVC.swift
//  Petcare
//
//  Created by SAIL on 09/10/23.
//

import UIKit

class UserVC: UIViewController {
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Email: UILabel!
    @IBOutlet weak var Number: UILabel!
    @IBOutlet weak var NameTF: UITextField!
    @IBOutlet weak var EmailTF: UITextField!
    @IBOutlet weak var NumberTF: UITextField!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var updateButton: UIButton!
    var userid: String = UserDefaultsManager.shared.getID()
    
    var pass: Account!
    
    var count: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
        
        self.NameTF.isHidden = true
        self.EmailTF.isHidden = true
        self.NumberTF.isHidden = true
        
        self.updateButton.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getProfileAPI()
    }
    
    func getProfileAPI() {
        APIHandler().getAPIValues(type: Account.self, apiUrl: Constants.serviceType.AccountAPI, method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data ?? "")
                
                DispatchQueue.main.async {
                    self.Name.text = self.pass.data?.first?.name
                    self.Email.text = self.pass.data?.first?.email
                    self.Number.text = self.pass.data?.first?.phoneNumber
                    
                    self.NameTF.text = self.pass.data?.first?.name
                    self.EmailTF.text = self.pass.data?.first?.email
                    self.NumberTF.text = self.pass.data?.first?.phoneNumber
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            }
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
        // Assuming you want to dismiss from ViewControllerA to ViewControllerB

        // In ViewControllerA
//        let viewController = self.storyboard?.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
//        self.dismiss(animated: true) {
//            self.present(viewController, animated: true, completion: nil)
//        }

    }
    
    @IBAction func editAction(_ sender: Any) {
        self.NameTF.isHidden = false
        self.EmailTF.isHidden = false
        self.NumberTF.isHidden = false
        
        self.updateButton.isHidden = false
    }
    
    @IBAction func updateAction(_ sender: Any) {
        ProfileUpdateAPI() 
        
        self.NameTF.isHidden = true
        self.EmailTF.isHidden = true
        self.NumberTF.isHidden = true
        
        self.updateButton.isHidden = true
        
    }
    func ProfileUpdateAPI() {
    let formData: [String: String] = [
        "name": NameTF.text ?? "",
        "email": EmailTF.text ?? "",
        "phone_number": NumberTF.text ?? "",
        "user_id": userid
    
    ]
    APIHandler().postAPIValues(type: UpdateJson.self, apiUrl: Constants.serviceType.ProfileUpdateAPI.rawValue, method: "POST", formData: formData) { result in
        switch result {
        case .success(let response):
            print("Status: \(response.status ?? "")")
            print("Message: \(response.message ?? "")")
            DispatchQueue.main.async {
                AlertManager.showAlert(title: "\(response.status ?? "")", message: "\(response.message ?? "")", viewController: self) {
                    self.getProfileAPI()
                }
    //                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
    //                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        case .failure(let error):
            print("Error: \(error)")
            DispatchQueue.main.async {
                AlertManager.showAlert(title: "Failure", message: "Profile updated failure!", viewController: self)
    //                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
    //                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        }
    }
    }
    
}
