//
//  InitialTabBar.swift
//  Petcare
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class InitialTabBar: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

}
