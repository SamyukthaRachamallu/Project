//
//  SelectpetTableViewCell.swift
//  Petcare
//
//  Created by SAIL on 30/10/23.
//

import UIKit

class SelectpetTableViewCell: UITableViewCell {
    
    @IBOutlet weak var PetName: UILabel!
    @IBOutlet weak var Breed: UILabel!
    @IBOutlet weak var selectButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
