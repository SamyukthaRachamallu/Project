//
//  InfoModel.swift
//  Petcare
//
//  Created by SAIL on 30/10/23.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Infopage
struct Infopage: Codable {
    var data: [Datum]?
}

// MARK: - Datum
struct Datum: Codable {
    var info: String?
}
