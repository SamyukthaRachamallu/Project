//
//  AddAddressVC.swift
//  Petcare
//
//  Created by SAIL on 31/10/23.
//

import UIKit

class AddAddressVC: UIViewController {

    @IBOutlet weak var Address: UILabel!
    @IBOutlet weak var AddressTF: UITextField!
    var userid: String = UserDefaultsManager.shared.getID()
    
    var vc : AddressVC?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func backAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func AddAddressAPI() {
    let formData: [String: String] = [
        "Address": AddressTF.text ?? "",
        "userID": userid
        
    ]
    APIHandler().postAPIValues(type: AddAddressJson.self, apiUrl: Constants.serviceType.AddAddressAPI.rawValue, method: "POST", formData: formData) { result in
        switch result {
        case .success(let response):
            print("Status: \(response.status)")
            print("Message: \(response.message)")
            DispatchQueue.main.async {
                AlertManager.showAlert(title: "\(response.status ?? "")", message: "\(response.message ?? "")", viewController: self) {
                    self.vc?.addressTableView.reloadData()
                    self.dismiss(animated: true, completion: nil)
                }
    //                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
    //                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        case .failure(let error):
            print("Error: \(error)")
        }
    }
    }

    
    @IBAction func SaveAction(_ sender: Any) {
     AddAddressAPI()
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
