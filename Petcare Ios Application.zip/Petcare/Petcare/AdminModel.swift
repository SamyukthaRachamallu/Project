//
//  AdminModel.swift
//  Petcare
//
//  Created by SAIL on 18/10/23.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)
// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct Admin: Codable {
    var data: [pages]?
}

// MARK: - Datum
struct pages: Codable {
       var service, type, petType, amount: String?
        var serviceID: String?

        enum CodingKeys: String, CodingKey {
            case service = "Service"
            case type = "Type"
            case petType = "PetType"
            case amount = "Amount"
            case serviceID = "ServiceID"
        }
    }

//enum PetType: String, Codable {
//    case cat = "Cat"
//    case dog = "Dog"
//}
//
//enum Service: String, Codable {
//    case veterinary = "Veterinary"
//}
