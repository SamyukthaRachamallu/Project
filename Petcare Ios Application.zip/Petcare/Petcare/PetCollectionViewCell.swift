//
//  PetCollectionViewCell.swift
//  Petcare
//
//  Created by Haris Madhavan on 18/11/23.
//

import UIKit

class PetCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var breedLabel: UILabel!
    @IBOutlet weak var genderLabel: UILabel!
    @IBOutlet weak var birthdayLabel: UILabel!
    @IBOutlet weak var petimage: UIImageView!
    
}
