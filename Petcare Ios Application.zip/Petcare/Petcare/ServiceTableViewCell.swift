//
//  ServiceTableViewCell.swift
//  Petcare
//
//  Created by SAIL on 11/10/23.
//

import UIKit

class ServiceTableViewCell: UITableViewCell {
    @IBOutlet weak var Service: UILabel!
    @IBOutlet weak var PetType: UILabel!
    @IBOutlet weak var SubCategory: UILabel!
    @IBOutlet weak var Price: UILabel!
    @IBOutlet weak var Delete: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
}
