//
//  MypetVC.swift
//  Petcare
//
//  Created by SAIL on 17/10/23.
//

import UIKit

class MypetVC: UIViewController {

    @IBOutlet weak var petCollectionView: UICollectionView!
    
    var pass: Pet!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.petCollectionView.delegate = self
        self.petCollectionView.dataSource = self
        
        let numbersOfColumns: CGFloat = 2
        let columnSpacing: CGFloat = (numbersOfColumns - 1) * 10
        let width = (self.view.frame.size.width - columnSpacing) / numbersOfColumns
        let layout = petCollectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: width, height: width)

        let direction = UICollectionViewFlowLayout()
        direction.scrollDirection = .vertical
        direction.itemSize = CGSize(width: self.petCollectionView.frame.size.width / 1.7, height: 300.0)
        self.petCollectionView.collectionViewLayout = direction
    }
    
    @IBAction func addPetAction(_ sender: Any) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "PetVC") as! PetVC
//        navigationController?.pushViewController(vc, animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyboard.instantiateViewController(withIdentifier: "PetVC") as! PetVC
        viewController.providesPresentationContextTransitionStyle = true
        viewController.definesPresentationContext = true
        viewController.modalPresentationStyle = UIModalPresentationStyle.overCurrentContext
        self.present(viewController, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getProfileAPI()
    }
    
    func getProfileAPI() {
        APIHandler().getAPIValues(type: Pet.self, apiUrl: Constants.serviceType.PetAPI, method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data ?? "")
                
                DispatchQueue.main.async {
                    self.petCollectionView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            }
        }
    }
    
}

extension MypetVC: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.pass?.data?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PetCollectionViewCell", for: indexPath) as! PetCollectionViewCell
        
        if let details = self.pass?.data?[indexPath.row] {
            cell.nameLabel.text = "\(details.petName ?? "")"
            cell.breedLabel.text = "Breed: \(details.breed ?? "")"
            cell.genderLabel.text = "Gender: \(details.petGender ?? "")"
            cell.birthdayLabel.text = "DOB: \(details.birthDay ?? "")"
        } else {
            cell.nameLabel.text = ""
            cell.breedLabel.text = ""
            cell.genderLabel.text = ""
            cell.birthdayLabel.text = ""
        }
        
        if let petType =  self.pass?.data?[indexPath.row] {
            if petType.petType == "Cat" {
                cell.petimage.image = UIImage(named: "cat")
            } else if petType.petType == "Dog" {
                cell.petimage.image = UIImage(named: "dog")
            }
        }
        return cell
    }
}

