//
//  BookingsModel.swift
//  Petcare
//
//  Created by SAIL on 01/11/23.
//

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct Bookings: Codable {
    var status: Bool?
    var message: String?
    var data: [bookings]?
}

// MARK: - Datum
struct bookings: Codable {
    var bookingID, service, pickupAddress, appointmentDate: String?
        var confirmed: String?

        enum CodingKeys: String, CodingKey {
            case bookingID = "BookingID"
            case service = "Service"
            case pickupAddress = "PickupAddress"
            case appointmentDate = "AppointmentDate"
            case confirmed
        }
    }
