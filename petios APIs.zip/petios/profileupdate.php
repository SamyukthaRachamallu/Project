<?php
// Include the database connection file
include 'db_conn.php';

header("Content-Type: application/json");

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the user_id from the POST data
    $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : null;

    if (!$user_id) {
        http_response_code(400); // Bad Request
        echo json_encode(["error" => "The 'user_id' parameter is required"]);
    } else {
        // Check if the user_id exists in the database
        $checkSql = "SELECT UserID FROM customer_details WHERE UserID = $user_id";
        $checkResult = $conn->query($checkSql);

        if ($checkResult->num_rows > 0) {
            // Parse the POST data for name, email, and phone_number
            $name = isset($_POST['name']) ? $_POST['name'] : null;
            $email = isset($_POST['email']) ? $_POST['email'] : null;
            $phone_number = isset($_POST['phone_number']) ? $_POST['phone_number'] : null;

            // Update the customer details in the database
            $updateSql = "UPDATE customer_details 
                          SET Name = '$name', Email = '$email', PhoneNumber = '$phone_number' 
                          WHERE UserID = $user_id";

            if ($conn->query($updateSql) === TRUE) {
                $response = [
                    "status" => "Success",
                    "message" => "Customer details updated successfully"
                ];
                echo json_encode($response);
            } else {
                http_response_code(500); // Internal Server Error
                echo json_encode(["error" => "Error updating customer details: " . $conn->error]);
            }
        } else {
            http_response_code(404); // Not Found
            echo json_encode(["error" => "User not found with the provided user_id"]);
        }
    }
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "Invalid request method. Use POST to update customer details"]);
}

// Close the database connection
$conn->close();
?>
