<?php
// Include the database connection file
include 'db_conn.php';

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $petid = $_POST['PetID'];
    $userID = $_POST['UserID'];
    $service = $_POST['Service'];
    $type = $_POST['Type'];
    $appointment = $_POST['AppointmentDate'];
    $time = $_POST['AppointmentTime'];
    $amount = $_POST['Amount'];
    $Hospital = $_POST['Hospital'];
    $address = $_POST['PickupAddress'];
     // Insert the new address into the database
    $sql = "INSERT INTO bookings (UserID, PetID, Service, Type, AppointmentDate, AppointmentTime, Amount, PickupAddress, Hospital)
            VALUES ( '$userID','$petid','$service','$type','$appointment','$time','$amount','$address', '$Hospital' )"; // Corrected column order

    if ($conn->query($sql) === TRUE) {
        $response = array('status' => 'success', 'message' => 'Address added successfully.');
        echo json_encode($response);
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
