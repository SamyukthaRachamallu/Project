<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Retrieve all rows from the designation table
    $sql = "SELECT * FROM designation";
    $result = $conn->query($sql);

    if ($result === FALSE) {
        // Handle query execution error
        $response = array('status' => 'error', 'message' => 'Error retrieving data: ' . $conn->error);
        echo json_encode($response);
    } else {
        // Initialize an array to store designation data
        $designations = array();

        // Fetch and store designation data
        while ($row = $result->fetch_assoc()) {
            $designation = array(
                'DesignationID' => $row['Id'],
                'Title' => $row['dest'],
                // Add other columns as needed
            );

            $designations[] = $designation;
        }

        // Output the designation data as JSON
        $response['data'] = $designations;
        echo json_encode($response);
    }
} else {
    // Handle non-GET requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
