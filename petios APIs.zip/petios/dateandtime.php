


<?php
require 'db_conn.php'; // Include your database connection script

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input parameters from the POST data
    $userID = $_POST['UserID'];
    $appointmentDate = $_POST['AppointmentDate'];
    $appointmentTime = $_POST['AppointmentTime'];

    // Prepare the SQL query with placeholders
    $query = "INSERT INTO bookings (UserID, AppointmentDate, AppointmentTime) VALUES (?, ?, ?)";

    // Prepare and execute the query
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sss", $userID, $appointmentDate, $appointmentTime); // Adjust types if needed

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Data inserted successfully']);
    } else {
        echo json_encode(['error' => 'Insertion error: ' . $conn->error]);
    }
} else {
    // Handle invalid HTTP method
    echo json_encode(['error' => 'Invalid HTTP method. Use POST.']);
}
?>
