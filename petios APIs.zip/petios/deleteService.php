<?php
require 'db_conn.php'; // Include your database connection script

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $serviceId = $_POST['ServiceID'];

    // Check if there is a matching row with the given serviceId in the "services" table
    $stmt = $conn->prepare("DELETE FROM services WHERE ServiceID = ?");

    if ($stmt) {
        $stmt->bind_param('i', $serviceId); // Assuming serviceID is an integer

        if ($stmt->execute()) {
            // Check the affected rows to confirm if a row was deleted
            if ($stmt->affected_rows > 0) {
                // Return a JSON response indicating success
                header('Content-Type: application/json');
                echo json_encode(['status' => 'success', 'message' => 'Service deleted successfully']);
            } else {
                // No rows were deleted, possibly because the serviceID was not found
                header('Content-Type: application/json', true, 400);
                echo json_encode(['message' => 'Service not found or could not be deleted']);
            }
        } else {
            // Execution of the delete query failed
            echo 'Delete query execution failed: ' . $conn->error;
        }
    } else {
        echo 'Failed to prepare delete query: ' . $conn->error;
    }
} else {
    // Invalid or missing parameters
    header('Content-Type: application/json', true, 400);
    echo json_encode(['message' => 'Invalid or missing parameters']);
}
?>
