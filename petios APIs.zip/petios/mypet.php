<?php
// get_pet_data.php

// Ensure that a UserID is provided as a GET parameter
if (isset($_GET['UserID'])) {
    // Get the UserID from the GET parameter
    $userID = $_GET['UserID'];

    header("Content-Type: application/json");

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pets_care";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve pet data for the specified user
    $result = $conn->query("SELECT * FROM pets WHERE UserID = '" . $userID . "'");
    $pets = [];

    // Change the if statement to a while loop
    while ($pet = $result->fetch_assoc()) {
        $pets[] = [
            "PetName" => $pet['PetName'],
            "Breed" => $pet['Breed'],
            "PetGender" => $pet['PetGender'],
            "BirthDay" => $pet['BirthDay'],
            "PetType" => $pet['PetType'],
        ];
    }

    // Check if any pets were found
    if (!empty($pets)) {
        $response['data'] = $pets;
        echo json_encode($response);
    } else {
        http_response_code(404); // Not Found
        echo json_encode(["error" => "No pets found for the specified user"]);
    }

    $conn->close();
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "UserID not provided in the GET request"]);
}
?>
