<?php
// Start or resume the session
session_start();

// Set the HTTP response headers
header('Content-Type: application/json; charset=UTF-8');

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    // Unset all session variables
    $_SESSION = array();

    // Destroy the session
    session_destroy();

    // Prepare the response
    $response = [
        'status' => true,
        'message' => 'Logout Successful'
    ];
} else {
    // If the user is not logged in
    $response = [
        'status' => false,
        'message' => 'Not Logged In'
    ];
}

// Send the JSON response
echo json_encode($response);
?>
