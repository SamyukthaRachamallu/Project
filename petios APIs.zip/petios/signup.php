<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the application
    $Name = $_POST['Name'];
    $Email = $_POST['Email'];
    $PhoneNumber = $_POST['PhoneNumber'];
    $Password = $_POST['Password'];

    // Check if the user_id already exists in customer_details
     $check_sql = "SELECT Email FROM customer_details WHERE Email = '$Email'";
    $check_result = $conn->query($check_sql);

    if ($check_result === FALSE) {
        // Handle query execution error
        $response = array('status' => 'error', 'message' => 'Error checking for existing user: ' . $conn->error);
        echo json_encode($response);
    } elseif ($check_result->num_rows > 0) {
        // User already exists
        $response = array('status' => 'error', 'message' => 'User already exists.');
        echo json_encode($response);
    } else {
        // Insert data into the customer_details table
        $sql = "INSERT INTO customer_details (Name, Email, PhoneNumber, Password) VALUES ('$Name', '$Email', '$PhoneNumber', '$Password')";

        if ($conn->query($sql) === TRUE) {
            // Successful insertion
            $response = array('status' => 'success', 'message' => 'User registration successful.');
            echo json_encode($response);
        } else {
            // Error in database insertion
            $response = array('status' => 'error', 'message' => 'Error inserting data: ' . $conn->error);
            echo json_encode($response);
        }
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
