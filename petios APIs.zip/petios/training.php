<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Retrieve facilities from the services table
    $sql = "SELECT Service, Type, PetType, Amount, ServiceID FROM services";
    $result = $conn->query($sql);

    if ($result === FALSE) {
        // Handle query execution error
        $response = array('status' => 'error', 'message' => 'Error retrieving data: ' . $conn->error);
        echo json_encode($response);
    } else {
        // Initialize an array to store training facilities
        $trainingFacilities = array();

        // Fetch and store training facilities separately
        while ($row = $result->fetch_assoc()) {
            if ($row['Service'] === 'Training') {
                $facility = array(
                    'Service' => $row['Service'],
                    'Type' => $row['Type'],
                    'PetType' => $row['PetType'],
                    'Amount' => $row['Amount'],
                    'ServiceID' => $row['ServiceID']
                );

                $trainingFacilities[] = $facility;
            }
        }

        // Output the training facilities as JSON
        
        $response['data'] =$trainingFacilities;

        echo json_encode($response);
    }
} else {
    // Handle non-GET requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
