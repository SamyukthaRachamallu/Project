<?php
// get_user_bookings.php

// Ensure that a UserID is provided as a GET parameter
if (isset($_GET['UserID'])) {
    // Get the UserID from the GET parameter
    $userID = $_GET['UserID'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pets_care";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Step 1: Retrieve user's designation from CUSTOMER_DETAILS
    $designationResult = $conn->query("SELECT designation FROM customer_details WHERE UserID = $userID");

    if ($designationResult->num_rows > 0) {
        $designationRow = $designationResult->fetch_assoc();
        $designation = $designationRow['designation'];

        // Step 2: Retrieve respective ID from DEST based on designation
        $destResult = $conn->query("SELECT dest FROM designation WHERE Id = '$designation'");

        if ($destResult->num_rows > 0) {
            $destRow = $destResult->fetch_assoc();
            $destID = $destRow['dest'];

            // Step 3: Retrieve bookings from bookings table based on hospital ID
            // ...

// Step 3: Retrieve bookings from bookings table based on hospital ID
$bookingsResult = $conn->query("SELECT BookingID, Service, PickupAddress, AppointmentDate, confirmed FROM bookings WHERE Hospital = '$destID'");

// ...


            if ($bookingsResult === FALSE) {
                // Handle query execution error
                $response = array('status' => 'error', 'message' => 'Error retrieving bookings: ' . $conn->error);
                echo json_encode($response);
            } else {
                $userArray = [];
            
                if ($bookingsResult->num_rows > 0) {
                    while ($row = $bookingsResult->fetch_assoc()) {
                        // Convert null to a string "null" if the value is null
                        $confirmedValue = is_null($row['confirmed']) ? "null" : $row['confirmed'];
            
                        $booking = [
                            "UserID" => $userID,
                            "BookingID" => $row['BookingID'],
                            "Service" => $row['Service'],
                            "PickupAddress" => $row['PickupAddress'],
                            "AppointmentDate" => $row['AppointmentDate'],
                            "confirmed" => $confirmedValue,
                        ];
                        $userArray[] = $booking;
                    }
            
                    $response['status'] = true;
                    $response['message'] = "User bookings retrieved successfully";
                    $response['data'] = $userArray;
                    echo json_encode($response);
                } else {
                    http_response_code(404); // Not Found
                    echo json_encode(["error" => "No bookings found for the specified user's hospital"]);
                }
            }
        }
    }

    $conn->close();
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "UserID not provided in the GET request"]);
}
?>
