<?php
// Include the database connection file
include 'db_conn.php';

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $address = $_POST['Address'];
    $userID = $_POST['userID'];
     // Insert the new address into the database
    $sql = "INSERT INTO address (UserID, Address)
            VALUES ('$userID', '$address')"; // Corrected column order

    if ($conn->query($sql) === TRUE) {
        $response = array('status' => 'Success', 'message' => 'Address added successfully.');
        echo json_encode($response);
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
