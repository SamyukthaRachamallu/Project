<?php
// Include the database connection file
include 'db_conn.php';

header("Content-Type: application/json");

// Get the input values for type and service from the query parameters
$type = isset($_GET['type']) ? $_GET['type'] : null;
$service = isset($_GET['service']) ? $_GET['service'] : null;

if (!$type || !$service) {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "Both 'type' and 'service' parameters are required"]);
} else {
    // Retrieve service and amount from the services table based on input criteria
    $sqlServices = "SELECT Type, Amount FROM services WHERE type = '$type' AND Service = '$service'";
    $resultServices = $conn->query($sqlServices);

    // Get the input value for userId
    $userId = isset($_GET['userId']) ? $_GET['userId'] : null;

    if (!$userId) {
        http_response_code(400); // Bad Request
        echo json_encode(["error" => "The 'userId' parameter is required"]);
    } else {
        // Retrieve the address from the address table based on userId
        $sqlAddress = "SELECT Address FROM address WHERE UserID = $userId";
        $resultAddress = $conn->query($sqlAddress);

        if ($resultServices->num_rows > 0 && $resultAddress->num_rows > 0) {
            $servicesData = $resultServices->fetch_assoc();
            $addressData = $resultAddress->fetch_assoc();

            $combinedData = [
                "type" => $servicesData['Type'],
                "amount" => $servicesData['Amount'],
                "address" => $addressData['Address'],
            ];
            $response = [
                "data" => [$combinedData],
            ];
            echo json_encode($response);
        } else {
            http_response_code(404); // Not Found
            echo json_encode(["error" => "No data found based on the provided criteria"]);
        }
    }
}

// Close the database connection
$conn->close();
?>
