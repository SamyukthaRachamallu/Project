<?php
// Include the database connection file
include 'db_conn.php';

header("Content-Type: application/json");

// Get the user_id from the query parameters
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;

if (!$user_id) {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "The 'user_id' parameter is required"]);
} else {
    // Retrieve the username from the customer_details table based on the user_id
    $user_query = "SELECT Name FROM customer_details WHERE UserID = $user_id";
    $user_result = $conn->query($user_query);

    if ($user_result->num_rows > 0) {
        $user_row = $user_result->fetch_assoc();
        $username = $user_row['Name'];

        // Retrieve addresses from the Address table based on the user_id
        $address_query = "SELECT Address FROM address WHERE UserID = $user_id";
        $address_result = $conn->query($address_query);

        if ($address_result->num_rows > 0) {
            $responses = [];

            while ($row = $address_result->fetch_assoc()) {
                $responses[] = [
                    "user_id" => $user_id,
                    "username" => $username,
                    "address" => $row['Address'],
                ];
            }

            echo json_encode(["data" => $responses]);
        } else {
            http_response_code(404); // Not Found
            echo json_encode(["error" => "No addresses found for the provided user_id"]);
        }
    } else {
        http_response_code(404); // Not Found
        echo json_encode(["error" => "No user found for the provided user_id"]);
    }
}

// Close the database connection
$conn->close();
?>
