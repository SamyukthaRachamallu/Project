<?php
// add_hospital.php

// Check if it's a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the input data from the request
    $hospitalId = $_POST['hospitalId'];
    $hospitalName = $_POST['hospitalName'];

    // Validate input data (you can add more validation as needed)

    // Include your database connection code here (e.g., db_conn.php)
    require_once('db_conn.php');

    // Prepare and execute the SQL query to insert data into the designation table
    $stmt = $conn->prepare("INSERT INTO designation (Id, dest) VALUES (?, ?)");
    $stmt->bind_param("ss", $hospitalId, $hospitalName);

    if ($stmt->execute()) {
        // Data inserted successfully
        http_response_code(201); // Created
        echo json_encode(['status' => 'Success', 'message' => 'Data inserted successfully']);
    } else {
        // Error in query execution
        http_response_code(500); // Internal Server Error
        echo json_encode(['error' => 'Error inserting data']);
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['error' => 'Only POST requests are allowed']);
}
?>
