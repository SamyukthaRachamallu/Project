<?php
// api.php

header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pets_care";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['UserID'])) {
        $userID = $_GET['UserID'];

        // Check if the user exists (you may want to add more validation here)
        $result = $conn->query("SELECT * FROM customer_details WHERE email = '$userID'");

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            
            $isAdmin = $row['isAdmin'];
            $cartItemCount = getCartItemCount($conn, $userID);
            $userArray = [];
            $userData = [
                "UserName" => $row['Name'],
                "isAdmin" => $isAdmin,
                "cartItems" => $cartItemCount,
            ];

            $response = [
                "status" => true,
                "message" => "User data retrieved successfully",
                "data" => $userData,
            ];
            $userArray[] = $userData;
            $response['data'] = $userArray;

            echo json_encode($response);
        } else {
            http_response_code(404); // Not Found
            echo json_encode(["error" => "User not found"]);
        }
    } else {
        http_response_code(400); // Bad Request
        echo json_encode(["error" => "UserID not provided in the GET request"]);
    }
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["error" => "Invalid request method"]);
}

$conn->close();

function getCartItemCount($conn, $userID) {
    $result = $conn->query("SELECT * FROM bookings WHERE IsInCart = 1 AND UserID = '$userID'");
    return $result->num_rows;
}
