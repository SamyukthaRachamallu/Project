<?php
// Include the database connection file
include 'db_conn.php';

header("Content-Type: application/json");

// Get the input value for type from the query parameters
$type = isset($_GET['type']) ? $_GET['type'] : null;

if (!$type) {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "The 'type' parameter is required"]);
} else {
    // Retrieve type and amount from the services table based on the input type
    $sql = "SELECT info FROM services WHERE Type = '$type'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        $response = [
            "data" => [
                [
                    "info" => $data['info'],
                    // "amount" => $data['Amount']
                ]
            ]
        ];
        echo json_encode($response);
    } else {
        http_response_code(404); // Not Found
        echo json_encode(["error" => "No data found for the provided type"]);
    }
}

// Close the database connection
$conn->close();
?>
