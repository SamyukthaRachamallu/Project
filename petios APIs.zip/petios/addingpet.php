<?php
// Include the database connection file
include 'db_conn.php';

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve data from the form
    $petname = $_POST['petname'];
    $pettype = $_POST['pettype'];
    $userID = $_POST['userID'];
    $petgender = $_POST['petgender'];
    $breed = $_POST['breed'];
    $birthday = $_POST['birthday'];

    // Insert the new pet into the database
    $sql = "INSERT INTO pets (petname, pettype, userID, petgender, breed, birthday)
            VALUES ('$petname', '$pettype', '$userID', '$petgender', '$breed', '$birthday')";

    if ($conn->query($sql) === TRUE) {
       
        $response = array('status' => 'success', 'message' => 'Pet added successfully.');
            echo json_encode($response);
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

