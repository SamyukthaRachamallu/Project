<?php
// Include your database connection script (e.g., db_conn.php)
require_once 'db_conn.php';

// Set the content type to JSON
header('Content-Type: application/json');

// Initialize an empty array to store the data
$data = [];

try {
    // Define your SQL query to retrieve three columns
    $query = "SELECT BookingID, Service, PickupAddress, AppointmentDate, UserID FROM bookings where confirmed is Null";

    // Prepare and execute the query
    $stmt = $conn->prepare($query);
    $stmt->execute();

    // Bind variables to the result columns
    $stmt->bind_result($col1, $col2, $col3,$col4,$col5);

    // Fetch the results and store them in the $data array
    while ($stmt->fetch()) {
        $data[] = [
            'BookingID' => $col1,
            'Service' => $col2,
            'PickupAddress' => $col3,
            'AppointmentDate' => $col4,
            'UserID' => $col5,
        ];
    }

    // Return the data as JSON
    $response['data'] = $data;
    echo json_encode($response);
} catch (Exception $e) {
    // Handle any database errors here
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
