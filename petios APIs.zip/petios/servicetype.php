<?php
// api.php

header("Content-Type: application/json");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pets_care";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['petType']) && isset($_GET['service'])) {
    $petType = $_GET['petType'];
    $service = $_GET['service'];

    $stmt = $conn->prepare("SELECT * FROM services WHERE PetType = ? AND Service = ?");
    $stmt->bind_param("ss", $petType, $service);
    $stmt->execute();
    $result = $stmt->get_result();

    $services = array();

    while ($row = $result->fetch_assoc()) {
        $services[] = $row;
    }
    $response['data'] = $services;
    echo json_encode($response);
} else {
    echo json_encode(["message" => "Invalid request"]);
}

$conn->close();
?>
