<?php
// get_user_bookings.php

// Ensure that a UserID is provided as a GET parameter
if (isset($_GET['UserID'])) {
    // Get the UserID from the GET parameter
    $userID = $_GET['UserID'];

    header("Content-Type: application/json");

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pets_care";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve user profile data for the specified user
    $result = $conn->query("SELECT BookingID, Service, PickupAddress, AppointmentDate, confirmed FROM bookings WHERE UserID = $userID ");

    $userArray = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Convert null to a string "null" if the value is null
            $confirmedValue = is_null($row['confirmed']) ? "null" : $row['confirmed'];

            $userProfile = [
                "BookingID" => $row['BookingID'],
                "Service" => $row['Service'],
                "PickupAddress" => $row['PickupAddress'],
                "AppointmentDate" => $row['AppointmentDate'],
                "confirmed" => $confirmedValue,
            ];
            $userArray[] = $userProfile;
        }

        $response['status'] = true;
        $response['message'] = "User bookings retrieved successfully";
        $response['data'] = $userArray;
        echo json_encode($response);
    } else {
        http_response_code(404); // Not Found
        echo json_encode(["error" => "User profile not found for the specified user"]);
    }

    $conn->close();
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "UserID not provided in the GET request"]);
}
?>
