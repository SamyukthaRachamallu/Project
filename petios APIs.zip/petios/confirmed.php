<?php
// bookings_count_api.php

// Include the database connection script
require_once('db_conn.php');

$response = [];

// Query to get the count of confirmed bookings
$resultConfirmed = $conn->query("SELECT COUNT(*) AS count FROM bookings WHERE confirmed = 1");

if ($resultConfirmed) {
    // Fetch the count from the result
    $rowConfirmed = $resultConfirmed->fetch_assoc();
    $countConfirmed = $rowConfirmed['count'];

    // Add the count to the response
    $response['data'][] = ['confirmed_bookings_count' => $countConfirmed];

    // Close the result set
    $resultConfirmed->close();
} else {
    http_response_code(500); // Internal Server Error
    $response['error'] = "Error executing confirmed bookings query: " . $conn->error;
}

// Query to get the count of canceled bookings

// Close the database connection
$conn->close();

// Set the content type to JSON
header("Content-Type: application/json");

// Return the JSON response
echo json_encode($response);
?>
