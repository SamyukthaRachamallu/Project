<?php
// get_user_profile.php

// Ensure that a UserID is provided as a GET parameter
if (isset($_GET['UserID'])) {
    // Get the UserID from the GET parameter
    $userID = $_GET['UserID'];

    header("Content-Type: application/json");

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pets_care";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve user profile data for the specified user
    $result = $conn->query("SELECT * FROM customer_details WHERE email = '" . $userID . "'");
    $userProfile = [];
    $userArray = [];

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        $userProfile = [
            "Name" => $row['Name'],
            "Email" => $row['Email'],
            "PhoneNumber" => $row['PhoneNumber'],
        ];
        $userArray[] = $userProfile;
        $response['status'] = true;
        $response['message'] = "User profile retrieved successfully";
        $response['data'] = $userArray;
        echo json_encode($response);
    } else {
        http_response_code(404); // Not Found
        echo json_encode(["error" => "User profile not found for the specified user"]);
    }

    $conn->close();
} else {
    http_response_code(400); // Bad Request
    echo json_encode(["error" => "UserID not provided in the GET request"]);
}
?>
